<?php
/**
 * SOS-Estudante
 * Controller de Histórico e Auditoria (Requisitos Seção 3.3).
 */

require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class HistoryController {
    private AuditLog $auditModel;

    public function __construct() {
        $this->auditModel = new AuditLog();
    }

    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $filters = [
            'action' => $_GET['action'] ?? '',
            'entity' => $_GET['entity'] ?? '',
            'search' => $_GET['search'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
        ];

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $totalLogs = $this->auditModel->countByUser($userId, $filters);
        $totalPages = ceil($totalLogs / $limit);
        $logs = $this->auditModel->getAllByUser($userId, $filters, $limit, $offset);

        $title = "Histórico e Auditoria - SOS-Estudante";
        require __DIR__ . '/../views/history/index.php';
    }
}
