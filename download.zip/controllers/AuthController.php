<?php
/**
 * SOS-Estudante
 * Controller de Autenticação e Perfil.
 */

require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../middlewares/GuestMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class AuthController {
    private AuthService $authService;

    public function __construct() {
        $this->authService = new AuthService();
    }

    public function showLogin(): void {
        GuestMiddleware::check();
        $title = "Entrar - SOS-Estudante";
        require __DIR__ . '/../views/auth/login.php';
    }

    public function processLogin(): void {
        GuestMiddleware::check();
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $result = $this->authService->login($email, $password);
        if ($result['success']) {
            set_flash('success', 'Bem-vindo de volta, ' . htmlspecialchars($result['user']['name']) . '!');
            redirect('index.php?route=dashboard');
        } else {
            set_flash('error', $result['error']);
            $_SESSION['old_email'] = $email;
            redirect('index.php?route=login');
        }
    }

    public function showRegister(): void {
        GuestMiddleware::check();
        $title = "Criar Conta - SOS-Estudante";
        require __DIR__ . '/../views/auth/register.php';
    }

    public function processRegister(): void {
        GuestMiddleware::check();
        $result = $this->authService->register($_POST);
        if ($result['success']) {
            // Realiza login automático após cadastro
            $this->authService->login($_POST['email'], $_POST['password']);
            set_flash('success', 'Conta criada com sucesso! Seja bem-vindo ao SOS-Estudante.');
            redirect('index.php?route=dashboard');
        } else {
            set_flash('error', $result['error']);
            $_SESSION['old_register'] = [
                'name' => $_POST['name'] ?? '',
                'email' => $_POST['email'] ?? '',
                'institution' => $_POST['institution'] ?? '',
                'course' => $_POST['course'] ?? ''
            ];
            redirect('index.php?route=register');
        }
    }

    public function logout(): void {
        $this->authService->logout();
        set_flash('info', 'Sessão encerrada com segurança.');
        redirect('index.php?route=login');
    }

    public function showProfile(): void {
        AuthMiddleware::check();
        $userModel = new User();
        $user = $userModel->findById($_SESSION['user_id']);
        $title = "Meu Perfil - SOS-Estudante";
        require __DIR__ . '/../views/auth/profile.php';
    }

    public function updateProfile(): void {
        AuthMiddleware::check();
        $result = $this->authService->updateProfile($_SESSION['user_id'], $_POST);
        if ($result['success']) {
            set_flash('success', 'Informações do perfil atualizadas!');
        } else {
            set_flash('error', $result['error']);
        }
        redirect('index.php?route=profile');
    }

    public function updatePassword(): void {
        AuthMiddleware::check();
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $newConfirm = $_POST['new_password_confirm'] ?? '';

        $result = $this->authService->updatePassword($_SESSION['user_id'], $current, $new, $newConfirm);
        if ($result['success']) {
            set_flash('success', 'Sua senha foi alterada com sucesso!');
        } else {
            set_flash('error', $result['error']);
        }
        redirect('index.php?route=profile');
    }
}
