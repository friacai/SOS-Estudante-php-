<?php
/**
 * SOS-Estudante
 * Controller da Grade Horária e Aulas.
 */

require_once __DIR__ . '/../services/ScheduleService.php';
require_once __DIR__ . '/../services/SubjectService.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class ScheduleController {
    private ScheduleService $scheduleService;
    private SubjectService $subjectService;

    public function __construct() {
        $this->scheduleService = new ScheduleService();
        $this->subjectService = new SubjectService();
    }

    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $schedule = $this->scheduleService->listSchedule($userId);
        $subjects = $this->subjectService->listSubjects($userId);

        // Agrupa por dia da semana
        $days = [
            1 => ['name' => 'Segunda-feira', 'classes' => []],
            2 => ['name' => 'Terça-feira', 'classes' => []],
            3 => ['name' => 'Quarta-feira', 'classes' => []],
            4 => ['name' => 'Quinta-feira', 'classes' => []],
            5 => ['name' => 'Sexta-feira', 'classes' => []],
            6 => ['name' => 'Sábado', 'classes' => []],
            7 => ['name' => 'Domingo', 'classes' => []],
        ];

        foreach ($schedule as $item) {
            $d = (int)$item['day_of_week'];
            if (isset($days[$d])) {
                $days[$d]['classes'][] = $item;
            }
        }

        $title = "Grade de Aulas - SOS-Estudante";
        require __DIR__ . '/../views/schedule/index.php';
    }

    public function store(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $result = $this->scheduleService->createSchedule($userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Aula adicionada à sua grade com sucesso!');
        } else {
            set_flash('error', $result['error']);
        }

        redirect('index.php?route=schedule');
    }

    public function delete(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->scheduleService->deleteSchedule($id, $userId);
        if ($result['success']) {
            set_flash('success', 'Horário removido da grade.');
        } else {
            set_flash('error', $result['error'] ?? 'Erro ao remover horário.');
        }

        redirect('index.php?route=schedule');
    }
}
