<?php
/**
 * SOS-Estudante
 * Controller de Disciplinas / Matérias.
 */

require_once __DIR__ . '/../services/SubjectService.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class SubjectController {
    private SubjectService $subjectService;

    public function __construct() {
        $this->subjectService = new SubjectService();
    }

    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $subjects = $this->subjectService->listSubjects($userId);

        $title = "Disciplinas - SOS-Estudante";
        require __DIR__ . '/../views/subjects/index.php';
    }

    public function store(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $result = $this->subjectService->createSubject($userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Disciplina adicionada com sucesso!');
        } else {
            set_flash('error', $result['error']);
        }

        redirect('index.php?route=subjects');
    }

    public function update(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->subjectService->updateSubject($id, $userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Disciplina atualizada com sucesso!');
        } else {
            set_flash('error', $result['error']);
        }

        redirect('index.php?route=subjects');
    }

    public function delete(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->subjectService->deleteSubject($id, $userId);
        if ($result['success']) {
            set_flash('success', 'Disciplina removida com sucesso!');
        } else {
            set_flash('error', $result['error'] ?? 'Erro ao remover disciplina.');
        }

        redirect('index.php?route=subjects');
    }
}
