<?php
/**
 * SOS-Estudante
 * Controller de Tarefas e Atividades.
 */

require_once __DIR__ . '/../services/TaskService.php';
require_once __DIR__ . '/../services/SubjectService.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class TaskController {
    private TaskService $taskService;
    private SubjectService $subjectService;

    public function __construct() {
        $this->taskService = new TaskService();
        $this->subjectService = new SubjectService();
    }

    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $filters = [
            'status' => $_GET['status'] ?? '',
            'priority' => $_GET['priority'] ?? '',
            'type' => $_GET['type'] ?? '',
            'subject_id' => $_GET['subject_id'] ?? '',
            'search' => $_GET['search'] ?? '',
            'sort' => $_GET['sort'] ?? 'due_date_asc'
        ];

        $tasks = $this->taskService->listTasks($userId, $filters);
        $subjects = $this->subjectService->listSubjects($userId);

        $title = "Atividades e Tarefas - SOS-Estudante";
        require __DIR__ . '/../views/tasks/index.php';
    }

    public function create(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $subjects = $this->subjectService->listSubjects($userId);
        
        $title = "Nova Atividade - SOS-Estudante";
        require __DIR__ . '/../views/tasks/create.php';
    }

    public function store(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $result = $this->taskService->createTask($userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Atividade cadastrada com sucesso!');
            redirect('index.php?route=tasks');
        } else {
            set_flash('error', $result['error']);
            redirect('index.php?route=tasks/create');
        }
    }

    public function edit(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_GET['id'] ?? 0);

        $task = $this->taskService->getTask($id, $userId);
        if (!$task) {
            set_flash('error', 'Atividade não encontrada.');
            redirect('index.php?route=tasks');
        }

        $subjects = $this->subjectService->listSubjects($userId);
        $title = "Editar Atividade - SOS-Estudante";
        require __DIR__ . '/../views/tasks/edit.php';
    }

    public function update(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->taskService->updateTask($id, $userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Atividade atualizada com sucesso!');
            redirect('index.php?route=tasks');
        } else {
            set_flash('error', $result['error']);
            redirect('index.php?route=tasks/edit&id=' . $id);
        }
    }

    public function toggle(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->taskService->toggleStatus($id, $userId);
        if ($result['success']) {
            $statusMsg = ($result['newStatus'] === 'Concluída') ? 'Atividade concluída! Parabéns!' : 'Atividade reaberta.';
            set_flash('success', $statusMsg);
        } else {
            set_flash('error', $result['error'] ?? 'Erro ao alterar status.');
        }

        $referrer = $_SERVER['HTTP_REFERER'] ?? 'index.php?route=tasks';
        redirect($referrer);
    }

    public function delete(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->taskService->deleteTask($id, $userId);
        if ($result['success']) {
            set_flash('success', 'Atividade excluída com sucesso.');
        } else {
            set_flash('error', $result['error'] ?? 'Erro ao excluir atividade.');
        }

        redirect('index.php?route=tasks');
    }
}
