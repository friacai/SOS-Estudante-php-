<?php
/**
 * SOS-Estudante
 * Controller de Anotações e Lembretes.
 */

require_once __DIR__ . '/../services/NoteService.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../config/app.php';

class NoteController {
    private NoteService $noteService;

    public function __construct() {
        $this->noteService = new NoteService();
    }

    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $search = $_GET['search'] ?? null;

        $notes = $this->noteService->listNotes($userId, $search);

        $title = "Anotações e Lembretes - SOS-Estudante";
        require __DIR__ . '/../views/notes/index.php';
    }

    public function store(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $result = $this->noteService->createNote($userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Anotação salva com sucesso!');
        } else {
            set_flash('error', $result['error']);
        }

        redirect('index.php?route=notes');
    }

    public function update(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->noteService->updateNote($id, $userId, $_POST);
        if ($result['success']) {
            set_flash('success', 'Anotação atualizada!');
        } else {
            set_flash('error', $result['error']);
        }

        redirect('index.php?route=notes');
    }

    public function togglePin(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $this->noteService->togglePin($id, $userId);
        redirect('index.php?route=notes');
    }

    public function delete(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];
        $id = (int)($_POST['id'] ?? 0);

        $result = $this->noteService->deleteNote($id, $userId);
        if ($result['success']) {
            set_flash('success', 'Anotação excluída.');
        } else {
            set_flash('error', $result['error'] ?? 'Erro ao excluir.');
        }

        redirect('index.php?route=notes');
    }
}
