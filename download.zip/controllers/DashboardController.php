<?php
/**
 * SOS-Estudante
 * Controller do Painel Principal (Dashboard).
 */

require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../models/Task.php';
require_once __DIR__ . '/../models/Subject.php';
require_once __DIR__ . '/../models/Schedule.php';
require_once __DIR__ . '/../models/Note.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class DashboardController {
    public function index(): void {
        AuthMiddleware::check();
        $userId = $_SESSION['user_id'];

        $taskModel = new Task();
        $subjectModel = new Subject();
        $scheduleModel = new Schedule();
        $noteModel = new Note();
        $auditModel = new AuditLog();

        $stats = $taskModel->getStats($userId);
        $upcomingTasks = $taskModel->getUpcoming($userId, 5);
        $totalSubjects = $subjectModel->countByUser($userId);
        
        $todayDayOfWeek = (int)date('N');
        $todaySchedule = $scheduleModel->getByUserAndDay($userId, $todayDayOfWeek);
        $notes = $noteModel->getAllByUser($userId);
        $pinnedNotes = array_filter($notes, fn($n) => $n['is_pinned'] == 1);
        $recentAudits = $auditModel->getAllByUser($userId, [], 5, 0);

        // Taxa de conclusão
        $completionRate = ($stats['total'] > 0) ? round(($stats['completed'] / $stats['total']) * 100) : 0;

        $title = "Dashboard - SOS-Estudante";
        require __DIR__ . '/../views/dashboard/index.php';
    }
}
