<?php
/**
 * SOS-Estudante
 * Middleware de Validação CSRF.
 */

require_once __DIR__ . '/../config/app.php';

class CsrfMiddleware {
    public static function validate(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['csrf_token'] ?? '';
            if (!verify_csrf_token($token)) {
                log_system('WARNING', 'Tentativa de requisição com CSRF Token inválido.', [
                    'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'uri' => $_SERVER['REQUEST_URI'] ?? ''
                ]);
                set_flash('error', 'Token de segurança expirado ou inválido. Tente novamente.');
                $referrer = $_SERVER['HTTP_REFERER'] ?? 'index.php?route=dashboard';
                redirect($referrer);
            }
        }
    }
}
