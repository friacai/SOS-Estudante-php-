<?php
/**
 * SOS-Estudante
 * Middleware para visitantes (não autenticados).
 */

require_once __DIR__ . '/../config/app.php';

class GuestMiddleware {
    public static function check(): void {
        if (!empty($_SESSION['user_id'])) {
            redirect('index.php?route=dashboard');
        }
    }
}
