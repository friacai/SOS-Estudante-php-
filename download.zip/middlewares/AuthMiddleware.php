<?php
/**
 * SOS-Estudante
 * Middleware de Autenticação.
 */

require_once __DIR__ . '/../config/app.php';

class AuthMiddleware {
    public static function check(): void {
        if (empty($_SESSION['user_id'])) {
            set_flash('error', 'Acesso restrito. Faça login para continuar.');
            redirect('index.php?route=login');
        }
    }

    public static function user(): ?array {
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        return [
            'id' => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'] ?? 'Estudante',
            'email' => $_SESSION['user_email'] ?? '',
            'course' => $_SESSION['user_course'] ?? '',
            'institution' => $_SESSION['user_institution'] ?? ''
        ];
    }
}
