<?php
/**
 * SOS-Estudante
 * Suíte de Testes Automatizados de Aceitação e Regras de Negócio.
 * Executável via CLI: php tests/run_tests.php
 */

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Subject.php';
require_once __DIR__ . '/../models/Task.php';
require_once __DIR__ . '/../models/Schedule.php';
require_once __DIR__ . '/../models/Note.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/TaskService.php';
require_once __DIR__ . '/../services/SubjectService.php';
require_once __DIR__ . '/../services/ScheduleService.php';
require_once __DIR__ . '/../services/NoteService.php';

class TestRunner {
    private int $passed = 0;
    private int $failed = 0;

    public function assert(bool $condition, string $testName): void {
        if ($condition) {
            echo " [PASS] " . $testName . PHP_EOL;
            $this->passed++;
        } else {
            echo " [FAIL] " . $testName . PHP_EOL;
            $this->failed++;
        }
    }

    public function runAll(): void {
        echo "===============================================" . PHP_EOL;
        echo " INICIANDO SUÍTE DE TESTES: SOS-ESTUDANTE" . PHP_EOL;
        echo "===============================================" . PHP_EOL;

        // 1. Teste de Conexão com o Banco de Dados PDO
        $db = Database::getConnection();
        $this->assert($db instanceof PDO, "Conexão PDO inicializada com sucesso (Driver: " . Database::getDriver() . ")");

        // 2. Teste de Autenticação e Hashing Seguro
        $authService = new AuthService();
        $testEmail = 'aluno_teste_' . time() . '@exemplo.com';
        $testPass = 'senhaSegura123';

        $regResult = $authService->register([
            'name' => 'Aluno Teste da Silva',
            'email' => $testEmail,
            'password' => $testPass,
            'password_confirm' => $testPass,
            'course' => 'Ciência da Computação',
            'institution' => 'Universidade Federal'
        ]);
        $this->assert($regResult['success'] === true, "Cadastro de novo estudante com senha hashada");
        $userId = $regResult['userId'];

        // Teste de duplicidade de email
        $dupResult = $authService->register([
            'name' => 'Aluno Duplicado',
            'email' => $testEmail,
            'password' => $testPass,
            'password_confirm' => $testPass
        ]);
        $this->assert($dupResult['success'] === false, "Bloqueio correto de cadastro com e-mail duplicado");

        // Teste de Login com senha correta
        $loginSuccess = $authService->login($testEmail, $testPass);
        $this->assert($loginSuccess['success'] === true, "Login bem-sucedido com validação password_verify()");

        // Teste de Login com senha errada
        $loginWrong = $authService->login($testEmail, 'senhaIncorreta');
        $this->assert($loginWrong['success'] === false, "Rejeição segura de credenciais com senha incorreta");

        // 3. Teste de Proteção CSRF
        $token = csrf_token();
        $this->assert(!empty($token) && strlen($token) === 64, "Geração de CSRF Token criptograficamente seguro");
        $this->assert(verify_csrf_token($token) === true, "Validação de CSRF Token válido");
        $this->assert(verify_csrf_token('tokenInvalido123') === false, "Rejeição de CSRF Token forjado");

        // 4. Teste de Disciplinas (Subjects)
        $subService = new SubjectService();
        $subRes = $subService->createSubject($userId, [
            'name' => 'Algoritmos e Estruturas de Dados',
            'code' => 'AED01',
            'teacher' => 'Prof. Alan Turing',
            'classroom' => 'Lab 101',
            'color' => '#10B981'
        ]);
        $this->assert($subRes['success'] === true, "Criação de Disciplina vinculada ao usuário");
        $subjectId = $subRes['id'];

        $subList = $subService->listSubjects($userId);
        $this->assert(count($subList) >= 1 && $subList[0]['name'] === 'Algoritmos e Estruturas de Dados', "Listagem de disciplinas do estudante");

        // 5. Teste de Tarefas e Atividades Acadêmicas (Tasks)
        $taskService = new TaskService();
        $taskRes = $taskService->createTask($userId, [
            'subject_id' => $subjectId,
            'title' => 'Implementação de Árvore Binária',
            'description' => 'Desenvolver métodos de inserção, busca e remoção balanceada.',
            'type' => 'Trabalho',
            'priority' => 'Alta',
            'status' => 'Pendente',
            'due_date' => date('Y-m-d', strtotime('+7 days')),
            'due_time' => '23:59'
        ]);
        $this->assert($taskRes['success'] === true, "Criação de Tarefa acadêmica com prazo e prioridade");
        $taskId = $taskRes['taskId'];

        // Alternar status da tarefa
        $toggleRes = $taskService->toggleStatus($taskId, $userId);
        $this->assert($toggleRes['success'] === true && $toggleRes['newStatus'] === 'Concluída', "Toggle de status para 'Concluída'");

        $toggleRes2 = $taskService->toggleStatus($taskId, $userId);
        $this->assert($toggleRes2['success'] === true && $toggleRes2['newStatus'] === 'Pendente', "Toggle de status de volta para 'Pendente'");

        // 6. Teste de Grade Horária (Schedule)
        $schedService = new ScheduleService();
        $schedRes = $schedService->createSchedule($userId, [
            'subject_id' => $subjectId,
            'day_of_week' => 1, // Segunda-feira
            'start_time' => '08:00',
            'end_time' => '10:00',
            'room' => 'Lab 101',
            'notes' => 'Aula prática'
        ]);
        $this->assert($schedRes['success'] === true, "Inclusão de aula na grade horária semanal");
        $schedId = $schedRes['id'];

        $schedList = $schedService->listSchedule($userId);
        $this->assert(count($schedList) >= 1, "Recuperação dos horários cadastrados");

        // 7. Teste de Anotações Rápidas (Notes)
        $noteService = new NoteService();
        $noteRes = $noteService->createNote($userId, [
            'title' => 'Resumo de Notação Big-O',
            'content' => 'O(1) < O(log n) < O(n) < O(n log n) < O(n^2)',
            'is_pinned' => 1
        ]);
        $this->assert($noteRes['success'] === true, "Criação de anotação de estudos fixada");
        $noteId = $noteRes['id'];

        // 8. Teste de Auditoria e Histórico (Requisitos Seção 3.3)
        $auditModel = new AuditLog();
        $logs = $auditModel->getAllByUser($userId);
        $this->assert(count($logs) >= 4, "Verificação de histórico de auditoria com ações registradas (Total: " . count($logs) . ")");

        // Verifica se NENHUM log contém senhas ou tokens
        $safeLogs = true;
        foreach ($logs as $log) {
            $text = json_encode($log);
            if (stripos($text, 'senhaSegura123') !== false || stripos($text, 'password_hash') !== false) {
                $safeLogs = false;
                break;
            }
        }
        $this->assert($safeLogs === true, "Integridade de Segurança: Registros de auditoria livres de senhas e tokens");

        echo "===============================================" . PHP_EOL;
        echo " RESULTADO FINAL: {$this->passed} PASSOU | {$this->failed} FALHOU" . PHP_EOL;
        echo "===============================================" . PHP_EOL;

        if ($this->failed > 0) {
            exit(1);
        }
    }
}

$runner = new TestRunner();
$runner->runAll();
