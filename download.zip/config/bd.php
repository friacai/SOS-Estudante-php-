<?php
/**
 * SOS-Estudante
 * Arquivo de configuração e conexão PDO com o Banco de Dados.
 * Suporta MySQL e SQLite com prepared statements e tratamento seguro de exceções.
 */

// Carrega variáveis do arquivo .env manualmente para manter o projeto leve e estruturado
function loadEnv($path = __DIR__ . '/../.env') {
    if (!file_exists($path)) {
        return;
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }
        if (strpos($line, '=') !== false) {
            list($key, $val) = explode('=', $line, 2);
            $key = trim($key);
            $val = trim($val);
            // Remove aspas simples ou duplas
            $val = trim($val, "\"'");
            if (!array_key_exists($key, $_ENV)) {
                $_ENV[$key] = $val;
                putenv("$key=$val");
            }
        }
    }
}

loadEnv();

class Database {
    private static ?PDO $instance = null;
    private static string $driverUsed = 'mysql';

    /**
     * Retorna a instância única da conexão PDO (Singleton Pattern)
     */
    public static function getConnection(): PDO {
        if (self::$instance === null) {
            self::connect();
        }
        return self::$instance;
    }

    /**
     * Retorna o driver que está sendo usado no momento (mysql ou sqlite)
     */
    public static function getDriver(): string {
        return self::$driverUsed;
    }

    private static function connect(): void {
        $driver = $_ENV['DB_DRIVER'] ?? 'mysql';
        $allowFallback = filter_var($_ENV['DB_ALLOW_SQLITE_FALLBACK'] ?? true, FILTER_VALIDATE_BOOLEAN);

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        // Tentativa de conexão MySQL
        if ($driver === 'mysql') {
            $host = $_ENV['DB_HOST'] ?? 'sql102.infinityfree.com';
            $port = $_ENV['DB_PORT'] ?? '3306';
            $dbname = $_ENV['DB_NAME'] ?? 'if0_43157025_base';
            $user = $_ENV['DB_USER'] ?? 'if0_43157025';
            $pass = $_ENV['DB_PASS'] ?? 'uV64AyITDQsGs';

            try {
                // Tenta conectar no MySQL
                $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
                self::$instance = new PDO($dsn, $user, $pass, $options);
                self::$driverUsed = 'mysql';
                return;
            } catch (PDOException $e) {
                // Se falhou ao conectar ao MySQL
                $logMessage = "[" . date('Y-m-d H:i:s') . "] Falha ao conectar ao MySQL: " . $e->getMessage() . PHP_EOL;
                @file_put_contents(__DIR__ . '/../logs/app.log', $logMessage, FILE_APPEND);

                if (!$allowFallback) {
                    die("Erro interno de conexão com o banco de dados. Consulte o log do sistema.");
                }

                // Fallback automático para SQLite
                self::connectSqlite($options);
            }
        } else {
            self::connectSqlite($options);
        }
    }

    private static function connectSqlite(array $options): void {
        $sqliteRelPath = $_ENV['DB_SQLITE_PATH'] ?? 'storage/database.sqlite';
        $sqlitePath = realpath(__DIR__ . '/../') . '/' . $sqliteRelPath;
        $dir = dirname($sqlitePath);
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }

        $isNew = !file_exists($sqlitePath);
        self::$instance = new PDO("sqlite:" . $sqlitePath, null, null, $options);
        self::$driverUsed = 'sqlite';

        // Se o arquivo SQLite foi criado agora, executa o schema inicial
        if ($isNew) {
            self::initializeSqliteDatabase();
        }
    }

    private static function initializeSqliteDatabase(): void {
        $schemaPath = __DIR__ . '/../database/schema_sqlite.sql';
        if (file_exists($schemaPath)) {
            $sql = file_get_contents($schemaPath);
            self::$instance->exec($sql);
        }
    }
}
