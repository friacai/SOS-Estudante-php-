<?php
/**
 * SOS-Estudante
 * Configuração Geral da Aplicação, Sessões e Utilitários Globais.
 */

require_once __DIR__ . '/bd.php';

// Definir timezone padrão
date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'America/Sao_Paulo');

// Inicialização segura de sessões nativas do PHP
if (session_status() === PHP_SESSION_NONE) {
    // Configurações de cookies de sessão seguras
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => (int)($_ENV['SESSION_LIFETIME'] ?? 7200),
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

/**
 * Utilitários para CSRF Token (Cross-Site Request Forgery)
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    $token = csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
}

function verify_csrf_token(?string $token): bool {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Utilitários para Mensagens Flash (Toast)
 */
function set_flash(string $type, string $message): void {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][] = [
        'type' => $type, // 'success', 'error', 'warning', 'info'
        'message' => $message
    ];
}

function get_flashes(): array {
    $flashes = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $flashes;
}

/**
 * Redirecionamento seguro
 */
function redirect(string $url): void {
    header("Location: " . $url);
    exit;
}

/**
 * Sanitização de saída HTML (anti-XSS)
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Helper para registrar logs operacionais
 */
function log_system(string $level, string $message, array $context = []): void {
    $date = date('Y-m-d H:i:s');
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0777, true);
    }
    // Remove qualquer senha ou dado sensível do contexto antes de gravar
    if (isset($context['password'])) unset($context['password']);
    if (isset($context['password_confirmation'])) unset($context['password_confirmation']);
    if (isset($context['token'])) unset($context['token']);

    $contextStr = !empty($context) ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logLine = "[{$date}] [{$level}] {$message}{$contextStr}" . PHP_EOL;
    @file_put_contents($logDir . '/app.log', $logLine, FILE_APPEND);
}
