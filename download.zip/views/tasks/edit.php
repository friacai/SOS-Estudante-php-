<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="max-w-3xl mx-auto space-y-6">
    
    <!-- Cabeçalho -->
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Editar Atividade</h1>
            <p class="text-sm text-slate-500">Atualize informações ou altere o status de conclusão</p>
        </div>
        <a href="index.php?route=tasks" class="text-xs font-semibold text-slate-500 hover:text-slate-800">
            &larr; Voltar para a lista
        </a>
    </div>

    <!-- Formulário -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <form action="index.php?route=tasks/update" method="POST" class="space-y-5">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $task['id'] ?>">

            <div>
                <label for="title" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Título da Atividade *
                </label>
                <input type="text" id="title" name="title" value="<?= e($task['title']) ?>" required autofocus
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label for="subject_id" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Disciplina / Matéria
                    </label>
                    <select id="subject_id" name="subject_id" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <option value="">Nenhuma disciplina</option>
                        <?php foreach ($subjects as $sub): ?>
                            <option value="<?= $sub['id'] ?>" <?= $task['subject_id'] == $sub['id'] ? 'selected' : '' ?>>
                                <?= e($sub['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="type" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Tipo
                    </label>
                    <select id="type" name="type" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <?php foreach (['Trabalho', 'Prova', 'Exercício', 'Leitura', 'Projeto', 'Outro'] as $t): ?>
                            <option value="<?= $t ?>" <?= $task['type'] === $t ? 'selected' : '' ?>><?= $t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="status" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Status Atual *
                    </label>
                    <select id="status" name="status" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white font-semibold text-brand-700">
                        <option value="Pendente" <?= $task['status'] === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                        <option value="Em Andamento" <?= $task['status'] === 'Em Andamento' ? 'selected' : '' ?>>Em Andamento</option>
                        <option value="Concluída" <?= $task['status'] === 'Concluída' ? 'selected' : '' ?>>Concluída</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label for="priority" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Prioridade *
                    </label>
                    <select id="priority" name="priority" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <?php foreach (['Baixa', 'Média', 'Alta', 'Urgente'] as $p): ?>
                            <option value="<?= $p ?>" <?= $task['priority'] === $p ? 'selected' : '' ?>><?= $p ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="due_date" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Data de Entrega *
                    </label>
                    <input type="date" id="due_date" name="due_date" value="<?= e($task['due_date']) ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label for="due_time" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Horário Limite
                    </label>
                    <input type="time" id="due_time" name="due_time" value="<?= !empty($task['due_time']) ? substr($task['due_time'], 0, 5) : '' ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>
            </div>

            <div>
                <label for="description" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Descrição Detalhada / Instruções
                </label>
                <textarea id="description" name="description" rows="4"
                          class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"><?= e($task['description']) ?></textarea>
            </div>

            <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <a href="index.php?route=tasks" class="px-5 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
                    Salvar Alterações
                </button>
            </div>
        </form>
    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
