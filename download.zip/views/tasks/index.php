<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-6">
    
    <!-- Cabeçalho & Botão Criar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Tarefas e Atividades Acadêmicas</h1>
            <p class="text-sm text-slate-500">Acompanhe trabalhos, provas, leituras e exercícios escolares</p>
        </div>
        <a href="index.php?route=tasks/create" 
           class="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Nova Atividade</span>
        </a>
    </div>

    <!-- Barra de Filtros e Busca (Mobile First) -->
    <div class="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200">
        <form method="GET" action="index.php" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <input type="hidden" name="route" value="tasks">

            <!-- Busca por texto -->
            <div class="lg:col-span-2">
                <input type="text" name="search" value="<?= e($filters['search']) ?>" 
                       placeholder="Buscar por título ou descrição..." 
                       class="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <!-- Filtro por Status -->
            <div>
                <select name="status" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Status: Todos</option>
                    <option value="Pendente" <?= $filters['status'] === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                    <option value="Em Andamento" <?= $filters['status'] === 'Em Andamento' ? 'selected' : '' ?>>Em Andamento</option>
                    <option value="Concluída" <?= $filters['status'] === 'Concluída' ? 'selected' : '' ?>>Concluída</option>
                </select>
            </div>

            <!-- Filtro por Prioridade -->
            <div>
                <select name="priority" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Prioridade: Todas</option>
                    <option value="Urgente" <?= $filters['priority'] === 'Urgente' ? 'selected' : '' ?>>Urgente</option>
                    <option value="Alta" <?= $filters['priority'] === 'Alta' ? 'selected' : '' ?>>Alta</option>
                    <option value="Média" <?= $filters['priority'] === 'Média' ? 'selected' : '' ?>>Média</option>
                    <option value="Baixa" <?= $filters['priority'] === 'Baixa' ? 'selected' : '' ?>>Baixa</option>
                </select>
            </div>

            <!-- Botões Filtrar / Limpar -->
            <div class="flex items-center gap-2">
                <button type="submit" class="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-all">
                    Filtrar
                </button>
                <a href="index.php?route=tasks" class="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all">
                    Limpar
                </a>
            </div>
        </form>
    </div>

    <!-- Lista de Tarefas -->
    <?php if (empty($tasks)): ?>
        <div class="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-300">
            <div class="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            </div>
            <h3 class="text-base font-bold text-slate-800">Nenhuma atividade encontrada</h3>
            <p class="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Você não tem atividades com os filtros selecionados. Crie uma nova tarefa para começar!</p>
            <div class="mt-5">
                <a href="index.php?route=tasks/create" class="inline-flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs rounded-xl shadow-md transition-all">
                    Criar Atividade
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($tasks as $task): 
                $isCompleted = ($task['status'] === 'Concluída');
                $isOverdue = (!$isCompleted && $task['due_date'] < date('Y-m-d'));
                $isToday = (!$isCompleted && $task['due_date'] === date('Y-m-d'));
            ?>
                <div class="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 <?= $isCompleted ? 'opacity-70 bg-slate-50/50' : '' ?>">
                    
                    <div class="flex items-start gap-3.5 flex-1 min-w-0">
                        <!-- Toggle de Status -->
                        <form action="index.php?route=tasks/toggle" method="POST" class="pt-0.5">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= $task['id'] ?>">
                            <button type="submit" title="<?= $isCompleted ? 'Reabrir tarefa' : 'Concluir tarefa' ?>"
                                    class="w-6 h-6 rounded-lg border-2 <?= $isCompleted ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 hover:border-emerald-500' ?> flex items-center justify-center transition-all">
                                <?php if ($isCompleted): ?>
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
                                <?php endif; ?>
                            </button>
                        </form>

                        <div class="space-y-1 min-w-0 flex-1">
                            <div class="flex items-center gap-2 flex-wrap">
                                <h3 class="text-base font-bold <?= $isCompleted ? 'line-through text-slate-400' : 'text-slate-900' ?>">
                                    <?= e($task['title']) ?>
                                </h3>
                                
                                <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider <?= $task['status'] === 'Concluída' ? 'bg-emerald-100 text-emerald-800' : ($task['status'] === 'Em Andamento' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700') ?>">
                                    <?= e($task['status']) ?>
                                </span>

                                <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider <?= $task['priority'] === 'Urgente' ? 'bg-rose-100 text-rose-700 font-extrabold' : ($task['priority'] === 'Alta' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600') ?>">
                                    <?= e($task['priority']) ?>
                                </span>

                                <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700">
                                    <?= e($task['type']) ?>
                                </span>
                            </div>

                            <?php if (!empty($task['description'])): ?>
                                <p class="text-xs text-slate-500 line-clamp-2"><?= nl2br(e($task['description'])) ?></p>
                            <?php endif; ?>

                            <div class="flex flex-wrap items-center gap-3 pt-1 text-xs">
                                <?php if (!empty($task['subject_name'])): ?>
                                    <span class="inline-flex items-center gap-1 font-medium text-slate-700">
                                        <span class="w-2.5 h-2.5 rounded-full" style="background-color: <?= e($task['subject_color']) ?>"></span>
                                        <?= e($task['subject_name']) ?>
                                    </span>
                                <?php endif; ?>

                                <span class="<?= $isOverdue ? 'text-rose-600 font-bold' : ($isToday ? 'text-amber-600 font-semibold' : 'text-slate-500') ?>">
                                    Prazo: <?= date('d/m/Y', strtotime($task['due_date'])) ?>
                                    <?= !empty($task['due_time']) ? ' às ' . substr($task['due_time'], 0, 5) : '' ?>
                                    <?= $isOverdue ? '(Atrasada!)' : ($isToday ? '(Entrega hoje!)' : '') ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Ações: Editar e Excluir -->
                    <div class="flex items-center gap-2 self-end sm:self-center">
                        <a href="index.php?route=tasks/edit&id=<?= $task['id'] ?>" 
                           class="p-2 text-slate-500 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all" title="Editar">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        </a>

                        <!-- Formulário com modal customizado (sem confirm nativo!) -->
                        <form action="index.php?route=tasks/delete" method="POST" 
                              data-confirm="Deseja realmente excluir a atividade '<?= e($task['title']) ?>'? Esta ação é irreversível." 
                              data-title="Excluir Atividade">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= $task['id'] ?>">
                            <button type="submit" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all" title="Excluir">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                            </button>
                        </form>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
