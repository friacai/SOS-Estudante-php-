<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="max-w-3xl mx-auto space-y-6">
    
    <!-- Cabeçalho -->
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Nova Atividade Acadêmica</h1>
            <p class="text-sm text-slate-500">Cadastre uma nova tarefa, trabalho, prova ou compromisso escolar</p>
        </div>
        <a href="index.php?route=tasks" class="text-xs font-semibold text-slate-500 hover:text-slate-800">
            &larr; Voltar para a lista
        </a>
    </div>

    <!-- Formulário -->
    <div class="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <form action="index.php?route=tasks/store" method="POST" class="space-y-5">
            <?= csrf_field() ?>

            <div>
                <label for="title" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Título da Atividade *
                </label>
                <input type="text" id="title" name="title" required autofocus
                       placeholder="Ex: Trabalho de Física - Dinâmica Newtoneana"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="subject_id" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Disciplina / Matéria
                    </label>
                    <select id="subject_id" name="subject_id" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <option value="">Selecione uma disciplina (opcional)</option>
                        <?php foreach ($subjects as $sub): ?>
                            <option value="<?= $sub['id'] ?>"><?= e($sub['name']) ?> <?= !empty($sub['code']) ? '(' . e($sub['code']) . ')' : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="type" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Tipo de Atividade
                    </label>
                    <select id="type" name="type" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <option value="Trabalho">Trabalho</option>
                        <option value="Prova">Prova / Avaliação</option>
                        <option value="Exercício">Lista de Exercícios</option>
                        <option value="Leitura">Leitura de Texto / Artigo</option>
                        <option value="Projeto">Projeto</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label for="priority" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Prioridade *
                    </label>
                    <select id="priority" name="priority" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                        <option value="Baixa">Baixa</option>
                        <option value="Média" selected>Média</option>
                        <option value="Alta">Alta</option>
                        <option value="Urgente">Urgente</option>
                    </select>
                </div>

                <div>
                    <label for="due_date" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Data de Entrega *
                    </label>
                    <input type="date" id="due_date" name="due_date" required min="<?= date('Y-m-d') ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label for="due_time" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Horário Limite (opcional)
                    </label>
                    <input type="time" id="due_time" name="due_time"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>
            </div>

            <div>
                <label for="description" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Descrição Detalhada / Instruções
                </label>
                <textarea id="description" name="description" rows="4"
                          placeholder="Anotações de critérios, formato ABNT, links de referência..."
                          class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white"></textarea>
            </div>

            <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <a href="index.php?route=tasks" class="px-5 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
                    Salvar Atividade
                </button>
            </div>
        </form>
    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
