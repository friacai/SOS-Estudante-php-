<?php
$title = "404 - Página Não Encontrada | SOS-Estudante";
require __DIR__ . '/../layouts/header.php';
?>

<div class="min-h-[60vh] flex flex-col items-center justify-center text-center p-6">
    <div class="w-20 h-20 rounded-3xl bg-brand-50 text-brand-600 flex items-center justify-center mb-6">
        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
    <h1 class="text-4xl font-extrabold text-slate-900 tracking-tight">404</h1>
    <h2 class="text-xl font-bold text-slate-700 mt-2">Página não encontrada</h2>
    <p class="text-sm text-slate-500 mt-2 max-w-md">
        O link que você tentou acessar não existe ou foi movido. Verifique o endereço digitado.
    </p>
    <div class="mt-6">
        <a href="index.php?route=dashboard" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
            Voltar ao Início
        </a>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
