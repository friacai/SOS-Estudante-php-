<?php
$title = "500 - Erro Interno | SOS-Estudante";
require __DIR__ . '/../layouts/header.php';
?>

<div class="min-h-[60vh] flex flex-col items-center justify-center text-center p-6">
    <div class="w-20 h-20 rounded-3xl bg-rose-50 text-rose-600 flex items-center justify-center mb-6">
        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
    </div>
    <h1 class="text-4xl font-extrabold text-slate-900 tracking-tight">500</h1>
    <h2 class="text-xl font-bold text-slate-700 mt-2">Ocorreu uma instabilidade interna</h2>
    <p class="text-sm text-slate-500 mt-2 max-w-md">
        Nossa equipe já foi notificada. Por motivos de segurança, detalhes técnicos foram preservados nos logs do servidor.
    </p>
    <div class="mt-6">
        <a href="index.php?route=dashboard" class="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
            Recarregar Página Inicial
        </a>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
