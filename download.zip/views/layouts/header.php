<?php
$currentUser = AuthMiddleware::user();
$currentRoute = $_GET['route'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="pt-BR" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'SOS-Estudante') ?></title>
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Estilos Personalizados -->
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body class="h-full flex flex-col font-sans text-slate-800 antialiased selection:bg-brand-500 selection:text-white">

<?php if ($currentUser): ?>
    <!-- Layout Privado para Estudantes Autenticados -->
    <div class="min-h-full flex flex-col md:flex-row">
        
        <!-- Sidebar Desktop (Fixa na lateral esquerda em telas médias e grandes) -->
        <aside class="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-slate-900 border-r border-slate-800 z-30">
            <div class="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto">
                
                <!-- Logo -->
                <div class="flex items-center flex-shrink-0 px-6 gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-400 flex items-center justify-center text-white shadow-lg shadow-brand-500/30">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                        </svg>
                    </div>
                    <div>
                        <span class="text-lg font-bold tracking-tight text-white">SOS<span class="text-brand-400">Estudante</span></span>
                        <span class="block text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Organização Acadêmica</span>
                    </div>
                </div>

                <!-- Perfil Rápido -->
                <div class="mt-6 px-4">
                    <div class="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-brand-500 text-white font-bold flex items-center justify-center flex-shrink-0">
                            <?= strtoupper(substr($currentUser['name'], 0, 1)) ?>
                        </div>
                        <div class="overflow-hidden">
                            <p class="text-sm font-semibold text-white truncate"><?= e($currentUser['name']) ?></p>
                            <p class="text-xs text-slate-400 truncate"><?= e($currentUser['course'] ?: 'Estudante') ?></p>
                        </div>
                    </div>
                </div>

                <!-- Links de Navegação -->
                <nav class="mt-6 flex-1 px-3 space-y-1">
                    <a href="index.php?route=dashboard" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'dashboard') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                        Dashboard
                    </a>

                    <a href="index.php?route=tasks" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'tasks') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                        Tarefas e Atividades
                    </a>

                    <a href="index.php?route=subjects" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'subjects') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                        Disciplinas
                    </a>

                    <a href="index.php?route=schedule" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'schedule') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                        Grade Horária
                    </a>

                    <a href="index.php?route=notes" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'notes') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        Anotações Rápidas
                    </a>

                    <!-- Seção 3.3 Histórico e Auditoria -->
                    <a href="index.php?route=history" class="group flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-all <?= strpos($currentRoute, 'history') !== false ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white' ?>">
                        <svg class="mr-3 flex-shrink-0 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        Histórico e Auditoria
                    </a>
                </nav>

                <!-- Rodapé da Sidebar -->
                <div class="px-3 pt-4 border-t border-slate-800 space-y-1">
                    <a href="index.php?route=profile" class="flex items-center px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white rounded-xl transition-all">
                        <svg class="mr-3 h-5 w-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                        Meu Perfil
                    </a>
                    <a href="index.php?route=logout" class="flex items-center px-3 py-2 text-sm font-medium text-rose-400 hover:bg-rose-950/40 rounded-xl transition-all">
                        <svg class="mr-3 h-5 w-5 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                        Sair do Sistema
                    </a>
                </div>

            </div>
        </aside>

        <!-- Navbar Superior Mobile (Apenas telas pequenas) -->
        <header class="md:hidden bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-40">
            <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                </div>
                <span class="text-base font-bold text-white">SOS<span class="text-brand-400">Estudante</span></span>
            </div>
            <button id="mobile-menu-toggle" type="button" class="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
        </header>

        <!-- Sidebar Gaveta Mobile (Drawer com backdrop) -->
        <div id="mobile-sidebar-backdrop" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 hidden md:hidden"></div>
        <aside id="mobile-sidebar" class="fixed inset-y-0 left-0 w-72 bg-slate-900 border-r border-slate-800 z-50 transform -translate-x-full transition-transform duration-300 ease-in-out md:hidden flex flex-col justify-between p-4">
            <div>
                <div class="flex items-center justify-between pb-4 border-b border-slate-800">
                    <span class="text-base font-bold text-white">Menu Principal</span>
                    <button id="mobile-sidebar-close" type="button" class="text-slate-400 hover:text-white p-1">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>
                <nav class="mt-4 space-y-1">
                    <a href="index.php?route=dashboard" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Dashboard</a>
                    <a href="index.php?route=tasks" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Tarefas e Atividades</a>
                    <a href="index.php?route=subjects" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Disciplinas</a>
                    <a href="index.php?route=schedule" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Grade Horária</a>
                    <a href="index.php?route=notes" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Anotações</a>
                    <a href="index.php?route=history" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Histórico e Auditoria</a>
                    <a href="index.php?route=profile" class="flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-slate-200 hover:bg-slate-800">Meu Perfil</a>
                </nav>
            </div>
            <div class="pt-4 border-t border-slate-800">
                <a href="index.php?route=logout" class="block w-full text-center px-4 py-2.5 rounded-xl text-sm font-semibold bg-rose-600/20 text-rose-400 border border-rose-500/30">
                    Sair do Sistema
                </a>
            </div>
        </aside>

        <!-- Conteúdo Principal Desktop & Mobile -->
        <div class="md:pl-64 flex flex-col flex-1">
            <main class="flex-1 py-6 px-4 sm:px-6 lg:px-8 max-w-7xl w-full mx-auto">
<?php else: ?>
    <!-- Layout para Telas Públicas (Login / Cadastro) -->
    <main class="flex-1 flex flex-col justify-center">
<?php endif; ?>
