<?php if (AuthMiddleware::user()): ?>
            </main>
            <!-- Rodapé da Aplicação -->
            <footer class="py-4 px-6 text-center text-xs text-slate-400 border-t border-slate-200/60 bg-white/50">
                &copy; <?= date('Y') ?> SOS-Estudante &bull; Plataforma de Gestão Acadêmica &bull; Seguro e Responsivo
            </footer>
        </div>
    </div>
<?php else: ?>
    </main>
    <footer class="py-4 text-center text-xs text-slate-400">
        &copy; <?= date('Y') ?> SOS-Estudante
    </footer>
<?php endif; ?>

<!-- Container Global para Toasts -->
<div id="toast-container" class="fixed top-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0"></div>

<!-- Scripts Globais -->
<script src="assets/js/main.js"></script>

<!-- Renderização Segura de Mensagens Flash como Toasts (Requisitos Seção 4.5) -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    <?php 
    $flashes = get_flashes();
    foreach ($flashes as $flash): 
    ?>
        window.showToast(<?= json_encode($flash['type']) ?>, <?= json_encode($flash['message']) ?>);
    <?php endforeach; ?>
});
</script>

</body>
</html>
