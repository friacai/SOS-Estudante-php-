<?php
require __DIR__ . '/../layouts/header.php';
$diasSemana = [1 => 'Segunda-feira', 2 => 'Terça-feira', 3 => 'Quarta-feira', 4 => 'Quinta-feira', 5 => 'Sexta-feira', 6 => 'Sábado', 7 => 'Domingo'];
$hojeTexto = $diasSemana[(int)date('N')] . ', ' . date('d/m/Y');
?>

<div class="space-y-6 sm:space-y-8">
    
    <!-- Banner de Boas-Vindas -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-r from-brand-600 via-indigo-600 to-purple-600 text-white p-6 sm:p-8 shadow-xl shadow-brand-500/20">
        <div class="relative z-10 max-w-2xl">
            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/20 backdrop-blur-md mb-3">
                <?= $hojeTexto ?>
            </span>
            <h1 class="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Olá, <?= e($currentUser['name']) ?>! 👋
            </h1>
            <p class="text-sm sm:text-base text-indigo-100 mt-2">
                Você possui <strong class="text-white"><?= $stats['pending'] ?> tarefa(s) pendente(s)</strong>, sendo <?= $stats['high_priority'] ?> de alta prioridade. Organize seu dia e bons estudos!
            </p>
            <div class="mt-5 flex flex-wrap gap-3">
                <a href="index.php?route=tasks/create" class="inline-flex items-center gap-2 px-4 py-2 bg-white text-brand-600 font-semibold text-xs sm:text-sm rounded-xl shadow hover:bg-slate-50 transition-all">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    Nova Tarefa
                </a>
                <a href="index.php?route=notes" class="inline-flex items-center gap-2 px-4 py-2 bg-brand-700/60 hover:bg-brand-700 text-white font-semibold text-xs sm:text-sm rounded-xl transition-all">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    Anotação Rápida
                </a>
            </div>
        </div>
        <!-- Efeito decorativo -->
        <div class="absolute -right-10 -bottom-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
    </div>

    <!-- Cards de Métricas e Estatísticas -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        <!-- Tarefas Pendentes -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-500">Pendentes</p>
                <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1"><?= $stats['pending'] ?></h3>
                <span class="text-[11px] text-amber-600 font-medium">Aguardando entrega</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
        </div>

        <!-- Concluídas -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-500">Concluídas</p>
                <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1"><?= $stats['completed'] ?></h3>
                <span class="text-[11px] text-emerald-600 font-medium"><?= $completionRate ?>% de progresso</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
        </div>

        <!-- Urgentes / Alta Prioridade -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-500">Alta Prioridade</p>
                <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1"><?= $stats['high_priority'] ?></h3>
                <span class="text-[11px] text-rose-600 font-medium">Atenção requerida</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
            </div>
        </div>

        <!-- Disciplinas Cadastradas -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-500">Disciplinas</p>
                <h3 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1"><?= $totalSubjects ?></h3>
                <span class="text-[11px] text-brand-600 font-medium">Matérias ativas</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
            </div>
        </div>

    </div>

    <!-- Barra de Progresso Geral -->
    <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80">
        <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold uppercase tracking-wider text-slate-600">Taxa de Conclusão Acadêmica</span>
            <span class="text-sm font-extrabold text-brand-600"><?= $completionRate ?>%</span>
        </div>
        <div class="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            <div class="bg-gradient-to-r from-brand-500 to-indigo-600 h-3 rounded-full transition-all duration-500" style="width: <?= $completionRate ?>%"></div>
        </div>
    </div>

    <!-- Grade Principal: Próximas Entregas + Horário de Hoje -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        
        <!-- Próximas Tarefas (2 Colunas) -->
        <div class="lg:col-span-2 space-y-4">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <svg class="w-5 h-5 text-brand-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    Próximas Entregas & Prazos
                </h2>
                <a href="index.php?route=tasks" class="text-xs font-semibold text-brand-600 hover:text-brand-700">Ver todas &rarr;</a>
            </div>

            <?php if (empty($upcomingTasks)): ?>
                <div class="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-300">
                    <div class="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                    </div>
                    <p class="text-sm font-semibold text-slate-800">Tudo em dia!</p>
                    <p class="text-xs text-slate-500 mt-1">Você não possui atividades com prazos pendentes no momento.</p>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-2xl divide-y divide-slate-100 shadow-sm border border-slate-200/80 overflow-hidden">
                    <?php foreach ($upcomingTasks as $task): 
                        $isOverdue = ($task['due_date'] < date('Y-m-d'));
                        $isToday = ($task['due_date'] === date('Y-m-d'));
                    ?>
                        <div class="p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50/80 transition-colors">
                            <div class="flex items-start gap-3 flex-1 min-w-0">
                                
                                <!-- Botão de marcar Concluído Rápido -->
                                <form action="index.php?route=tasks/toggle" method="POST" class="pt-1">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $task['id'] ?>">
                                    <button type="submit" title="Marcar como concluída" 
                                            class="w-5 h-5 rounded-md border-2 border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 transition-colors flex items-center justify-center">
                                    </button>
                                </form>

                                <div class="truncate">
                                    <h4 class="text-sm font-semibold text-slate-900 truncate">
                                        <?= e($task['title']) ?>
                                    </h4>
                                    <div class="flex flex-wrap items-center gap-2 mt-1">
                                        <?php if (!empty($task['subject_name'])): ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium" style="background-color: <?= e($task['subject_color']) ?>15; color: <?= e($task['subject_color']) ?>">
                                                <?= e($task['subject_name']) ?>
                                            </span>
                                        <?php endif; ?>

                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium <?= $task['priority'] === 'Urgente' ? 'bg-rose-100 text-rose-700 font-bold' : ($task['priority'] === 'Alta' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600') ?>">
                                            <?= e($task['priority']) ?>
                                        </span>

                                        <span class="text-xs <?= $isOverdue ? 'text-rose-600 font-bold' : ($isToday ? 'text-amber-600 font-semibold' : 'text-slate-500') ?>">
                                            Prazo: <?= date('d/m/Y', strtotime($task['due_date'])) ?>
                                            <?= !empty($task['due_time']) ? ' às ' . substr($task['due_time'], 0, 5) : '' ?>
                                            <?= $isOverdue ? '(Atrasada)' : ($isToday ? '(Hoje!)' : '') ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <a href="index.php?route=tasks/edit&id=<?= $task['id'] ?>" class="p-2 text-slate-400 hover:text-brand-600 rounded-lg hover:bg-slate-100 transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Grade Horária de Hoje & Aulas (1 Coluna) -->
        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <svg class="w-5 h-5 text-brand-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    Aulas de Hoje
                </h2>
                <a href="index.php?route=schedule" class="text-xs font-semibold text-brand-600 hover:text-brand-700">Ver grade &rarr;</a>
            </div>

            <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 space-y-3">
                <?php if (empty($todaySchedule)): ?>
                    <div class="text-center py-6 text-slate-400">
                        <svg class="w-10 h-10 mx-auto mb-2 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <p class="text-xs font-medium">Nenhuma aula programada para hoje.</p>
                        <p class="text-[11px] text-slate-400 mt-1">Aproveite para adiantar suas tarefas!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($todaySchedule as $cls): ?>
                        <div class="p-3.5 rounded-xl border border-l-4 border-slate-200 flex items-center justify-between" style="border-left-color: <?= e($cls['subject_color']) ?>">
                            <div>
                                <h4 class="text-sm font-bold text-slate-900"><?= e($cls['subject_name']) ?></h4>
                                <p class="text-xs text-slate-500 mt-0.5">
                                    <?= substr($cls['start_time'], 0, 5) ?> - <?= substr($cls['end_time'], 0, 5) ?>
                                    <?= !empty($cls['room']) ? '&bull; Sala: ' . e($cls['room']) : '' ?>
                                </p>
                            </div>
                            <?php if (!empty($cls['teacher'])): ?>
                                <span class="text-[11px] text-slate-400 italic">Prof. <?= e($cls['teacher']) ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Anotações Rápidas Fixadas -->
            <?php if (!empty($pinnedNotes)): ?>
                <div class="pt-2">
                    <h3 class="text-sm font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                        <svg class="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                        Lembretes Fixados
                    </h3>
                    <div class="space-y-2">
                        <?php foreach ($pinnedNotes as $pNote): ?>
                            <div class="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900">
                                <strong class="block font-bold mb-0.5"><?= e($pNote['title']) ?></strong>
                                <p class="line-clamp-2"><?= nl2br(e($pNote['content'])) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>

    </div>

    <!-- Seção de Auditoria Recente no Dashboard (Conforme Seção 3.3) -->
    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Atividades Recentes & Histórico de Operações
            </h3>
            <a href="index.php?route=history" class="text-xs font-semibold text-brand-600 hover:text-brand-700">Ver auditoria completa &rarr;</a>
        </div>

        <?php if (empty($recentAudits)): ?>
            <p class="text-xs text-slate-400">Nenhuma operação registrada ainda.</p>
        <?php else: ?>
            <div class="divide-y divide-slate-100 text-xs">
                <?php foreach ($recentAudits as $log): ?>
                    <div class="py-2.5 flex items-center justify-between gap-4">
                        <div class="flex items-center gap-2.5">
                            <span class="px-2 py-0.5 rounded font-bold uppercase text-[10px] <?= $log['action'] === 'CREATE' ? 'bg-emerald-100 text-emerald-700' : ($log['action'] === 'DELETE' ? 'bg-rose-100 text-rose-700' : ($log['action'] === 'COMPLETE' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700')) ?>">
                                <?= e($log['action']) ?>
                            </span>
                            <span class="text-slate-700"><?= e($log['description']) ?></span>
                        </div>
                        <span class="text-slate-400 whitespace-nowrap"><?= date('d/m/Y H:i', strtotime($log['created_at'])) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
