<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-6">
    
    <!-- Cabeçalho & Botão Criar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Anotações & Lembretes Rápidos</h1>
            <p class="text-sm text-slate-500">Guarde resumos, ideias de estudos, fórmulas e lembretes importantes</p>
        </div>
        <button type="button" onclick="openNoteModal()"
                class="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Nova Anotação</span>
        </button>
    </div>

    <!-- Barra de Busca -->
    <div class="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
        <form method="GET" action="index.php" class="flex gap-3">
            <input type="hidden" name="route" value="notes">
            <input type="text" name="search" value="<?= e($search) ?>" 
                   placeholder="Pesquisar por palavras-chave nas anotações..." 
                   class="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            <button type="submit" class="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-all">
                Buscar
            </button>
            <?php if (!empty($search)): ?>
                <a href="index.php?route=notes" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all flex items-center">
                    Limpar
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Lista de Anotações -->
    <?php if (empty($notes)): ?>
        <div class="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-300">
            <div class="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
            </div>
            <h3 class="text-base font-bold text-slate-800">Nenhuma anotação encontrada</h3>
            <p class="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Crie lembretes rápidos ou salve fórmulas e ideias de estudo para consultar quando precisar.</p>
            <div class="mt-5">
                <button type="button" onclick="openNoteModal()" class="inline-flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs rounded-xl shadow-md transition-all">
                    Criar Anotação
                </button>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <?php foreach ($notes as $note): 
                $isPinned = (bool)$note['is_pinned'];
            ?>
                <div class="bg-white rounded-2xl p-5 shadow-sm border <?= $isPinned ? 'border-amber-300 ring-2 ring-amber-100' : 'border-slate-200/80' ?> hover:shadow-md transition-all flex flex-col justify-between">
                    <div>
                        <!-- Header do Card -->
                        <div class="flex items-start justify-between gap-3 mb-2">
                            <h3 class="text-base font-bold text-slate-900"><?= e($note['title']) ?></h3>
                            
                            <!-- Botão Fixar / Desafixar -->
                            <form action="index.php?route=notes/pin" method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $note['id'] ?>">
                                <button type="submit" title="<?= $isPinned ? 'Desafixar lembrete' : 'Fixar no topo' ?>" 
                                        class="p-1 rounded-lg text-slate-300 hover:text-amber-500 <?= $isPinned ? 'text-amber-500' : '' ?> transition-colors">
                                    <svg class="w-4 h-4" fill="<?= $isPinned ? 'currentColor' : 'none' ?>" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                                </button>
                            </form>
                        </div>

                        <!-- Conteúdo -->
                        <p class="text-xs text-slate-600 whitespace-pre-line leading-relaxed mb-4">
                            <?= nl2br(e($note['content'])) ?>
                        </p>
                    </div>

                    <!-- Rodapé do Card -->
                    <div class="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                        <span>Atualizado em <?= date('d/m/Y', strtotime($note['updated_at'])) ?></span>
                        
                        <div class="flex items-center gap-1">
                            <button type="button" onclick='editNote(<?= json_encode($note) ?>)'
                                    class="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-all" title="Editar">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            </button>

                            <form action="index.php?route=notes/delete" method="POST"
                                  data-confirm="Deseja excluir a anotação '<?= e($note['title']) ?>'?"
                                  data-title="Excluir Anotação">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $note['id'] ?>">
                                <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Excluir">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Modal Criar / Editar Anotação -->
<div id="note-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm hidden animate-fade-in">
    <div class="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-100 animate-slide-down">
        
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <h3 id="note-modal-title" class="text-lg font-bold text-slate-900">Nova Anotação</h3>
            <button type="button" onclick="closeNoteModal()" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <form id="note-form" action="index.php?route=notes/store" method="POST" class="space-y-4">
            <?= csrf_field() ?>
            <input type="hidden" id="note-id" name="id" value="">

            <div>
                <label for="modal-note-title" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Título do Lembrete *
                </label>
                <input type="text" id="modal-note-title" name="title" required placeholder="Ex: Fórmulas de Cinemática ou Dicas de Redação"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div>
                <label for="modal-note-content" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Conteúdo da Anotação *
                </label>
                <textarea id="modal-note-content" name="content" rows="6" required placeholder="Escreva suas anotações aqui..."
                          class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"></textarea>
            </div>

            <div class="flex items-center gap-2">
                <input type="checkbox" id="modal-note-pin" name="is_pinned" value="1" class="w-4 h-4 rounded text-brand-600 focus:ring-brand-500">
                <label for="modal-note-pin" class="text-xs font-semibold text-slate-700">Fixar este lembrete em destaque no topo</label>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3">
                <button type="button" onclick="closeNoteModal()" class="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
                    Cancelar
                </button>
                <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                    Salvar Anotação
                </button>
            </div>
        </form>

    </div>
</div>

<script>
function openNoteModal() {
    const modal = document.getElementById('note-modal');
    document.getElementById('note-form').action = 'index.php?route=notes/store';
    document.getElementById('note-modal-title').textContent = 'Nova Anotação';
    document.getElementById('note-id').value = '';
    document.getElementById('modal-note-title').value = '';
    document.getElementById('modal-note-content').value = '';
    document.getElementById('modal-note-pin').checked = false;
    modal.classList.remove('hidden');
}

function editNote(note) {
    const modal = document.getElementById('note-modal');
    document.getElementById('note-form').action = 'index.php?route=notes/update';
    document.getElementById('note-modal-title').textContent = 'Editar Anotação';
    document.getElementById('note-id').value = note.id;
    document.getElementById('modal-note-title').value = note.title;
    document.getElementById('modal-note-content').value = note.content;
    document.getElementById('modal-note-pin').checked = (note.is_pinned == 1);
    modal.classList.remove('hidden');
}

function closeNoteModal() {
    document.getElementById('note-modal').classList.add('hidden');
}
</script>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
