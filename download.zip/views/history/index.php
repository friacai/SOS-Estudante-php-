<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-6">
    
    <!-- Cabeçalho -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Histórico de Operações & Auditoria</h1>
            <p class="text-sm text-slate-500">Registro completo e imutável de todas as ações e alterações realizadas na conta</p>
        </div>
        <div class="text-xs text-slate-500 bg-slate-100 py-1.5 px-3 rounded-lg border border-slate-200">
            Total registrado: <strong><?= $totalLogs ?></strong> evento(s)
        </div>
    </div>

    <!-- Barra de Filtros de Auditoria -->
    <div class="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200">
        <form method="GET" action="index.php" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <input type="hidden" name="route" value="history">

            <!-- Busca por descrição -->
            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Buscar por termo</label>
                <input type="text" name="search" value="<?= e($filters['search']) ?>" 
                       placeholder="Termo na descrição..." 
                       class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <!-- Filtro de Ação -->
            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Ação</label>
                <select name="action" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Todas as Ações</option>
                    <option value="CREATE" <?= $filters['action'] === 'CREATE' ? 'selected' : '' ?>>Criação (CREATE)</option>
                    <option value="UPDATE" <?= $filters['action'] === 'UPDATE' ? 'selected' : '' ?>>Atualização (UPDATE)</option>
                    <option value="DELETE" <?= $filters['action'] === 'DELETE' ? 'selected' : '' ?>>Exclusão (DELETE)</option>
                    <option value="COMPLETE" <?= $filters['action'] === 'COMPLETE' ? 'selected' : '' ?>>Conclusão (COMPLETE)</option>
                    <option value="REOPEN" <?= $filters['action'] === 'REOPEN' ? 'selected' : '' ?>>Reabertura (REOPEN)</option>
                    <option value="LOGIN" <?= $filters['action'] === 'LOGIN' ? 'selected' : '' ?>>Acesso (LOGIN)</option>
                    <option value="LOGOUT" <?= $filters['action'] === 'LOGOUT' ? 'selected' : '' ?>>Saída (LOGOUT)</option>
                </select>
            </div>

            <!-- Filtro de Entidade -->
            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">Módulo / Entidade</label>
                <select name="entity" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Todos os Módulos</option>
                    <option value="tarefa" <?= $filters['entity'] === 'tarefa' ? 'selected' : '' ?>>Tarefas</option>
                    <option value="materia" <?= $filters['entity'] === 'materia' ? 'selected' : '' ?>>Disciplinas</option>
                    <option value="horario" <?= $filters['entity'] === 'horario' ? 'selected' : '' ?>>Grade Horária</option>
                    <option value="nota" <?= $filters['entity'] === 'nota' ? 'selected' : '' ?>>Anotações</option>
                    <option value="usuario" <?= $filters['entity'] === 'usuario' ? 'selected' : '' ?>>Usuário / Perfil</option>
                </select>
            </div>

            <!-- Filtro Data Início -->
            <div>
                <label class="block text-[11px] font-bold uppercase text-slate-500 mb-1">A partir de</label>
                <input type="date" name="date_from" value="<?= e($filters['date_from']) ?>" 
                       class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <!-- Botões Aplicar / Limpar -->
            <div class="flex items-end gap-2">
                <button type="submit" class="flex-1 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-all">
                    Filtrar
                </button>
                <a href="index.php?route=history" class="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all">
                    Limpar
                </a>
            </div>
        </form>
    </div>

    <!-- Tabela / Lista de Auditoria -->
    <div class="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <?php if (empty($logs)): ?>
            <div class="p-12 text-center text-slate-400 text-xs">
                Nenhum registro de auditoria encontrado com os filtros aplicados.
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs text-slate-600">
                    <thead class="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[11px] tracking-wider">
                        <tr>
                            <th class="py-3 px-4">Data / Hora</th>
                            <th class="py-3 px-4">Operação</th>
                            <th class="py-3 px-4">Módulo</th>
                            <th class="py-3 px-4">Descrição da Atividade</th>
                            <th class="py-3 px-4">IP / Origem</th>
                            <th class="py-3 px-4 text-right">Auditoria</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php foreach ($logs as $log): 
                            $badgeColor = 'bg-slate-100 text-slate-700';
                            if ($log['action'] === 'CREATE') $badgeColor = 'bg-emerald-100 text-emerald-800 font-bold';
                            if ($log['action'] === 'UPDATE') $badgeColor = 'bg-blue-100 text-blue-800 font-bold';
                            if ($log['action'] === 'DELETE') $badgeColor = 'bg-rose-100 text-rose-800 font-bold';
                            if ($log['action'] === 'COMPLETE') $badgeColor = 'bg-teal-100 text-teal-800 font-bold';
                            if ($log['action'] === 'LOGIN') $badgeColor = 'bg-indigo-100 text-indigo-800';
                            if ($log['action'] === 'LOGOUT') $badgeColor = 'bg-amber-100 text-amber-800';
                        ?>
                            <tr class="hover:bg-slate-50/60 transition-colors">
                                <td class="py-3.5 px-4 font-mono text-slate-500 whitespace-nowrap">
                                    <?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?>
                                </td>
                                <td class="py-3.5 px-4">
                                    <span class="inline-flex px-2 py-0.5 rounded text-[10px] uppercase font-bold <?= $badgeColor ?>">
                                        <?= e($log['action']) ?>
                                    </span>
                                </td>
                                <td class="py-3.5 px-4 capitalize font-medium text-slate-800">
                                    <?= e($log['entity']) ?>
                                </td>
                                <td class="py-3.5 px-4 font-medium text-slate-800">
                                    <?= e($log['description']) ?>
                                </td>
                                <td class="py-3.5 px-4 font-mono text-slate-400">
                                    <?= e($log['ip_address'] ?? '-') ?>
                                </td>
                                <td class="py-3.5 px-4 text-right">
                                    <?php if (!empty($log['old_values']) || !empty($log['new_values'])): ?>
                                        <button type="button" 
                                                onclick='showAuditDetails(<?= json_encode($log) ?>)'
                                                class="px-2.5 py-1 text-[11px] font-semibold text-brand-600 hover:text-brand-700 hover:bg-brand-50 rounded-lg transition-colors">
                                            Ver Alterações
                                        </button>
                                    <?php else: ?>
                                        <span class="text-slate-300">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginação -->
            <?php if ($totalPages > 1): ?>
                <div class="p-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>Página <?= $page ?> de <?= $totalPages ?></span>
                    <div class="flex items-center gap-2">
                        <?php if ($page > 1): ?>
                            <a href="index.php?route=history&page=<?= $page - 1 ?>&action=<?= urlencode($filters['action']) ?>&entity=<?= urlencode($filters['entity']) ?>&search=<?= urlencode($filters['search']) ?>" 
                               class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium transition-colors">
                                &larr; Anterior
                            </a>
                        <?php endif; ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="index.php?route=history&page=<?= $page + 1 ?>&action=<?= urlencode($filters['action']) ?>&entity=<?= urlencode($filters['entity']) ?>&search=<?= urlencode($filters['search']) ?>" 
                               class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium transition-colors">
                                Próxima &rarr;
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

</div>

<!-- Modal de Detalhes da Auditoria (Valores anteriores e posteriores) -->
<div id="audit-details-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm hidden animate-fade-in">
    <div class="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 animate-slide-down">
        
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <div>
                <h3 class="text-base font-bold text-slate-900">Detalhes do Registro de Auditoria</h3>
                <p id="audit-modal-subtitle" class="text-xs text-slate-500"></p>
            </div>
            <button type="button" onclick="closeAuditDetails()" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <div class="space-y-4 text-xs">
            <div id="audit-old-section">
                <h4 class="font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1 text-rose-600">Valores Anteriores:</h4>
                <pre id="audit-old-json" class="p-3 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px] overflow-x-auto text-slate-700"></pre>
            </div>

            <div id="audit-new-section">
                <h4 class="font-bold text-slate-700 uppercase tracking-wider text-[11px] mb-1 text-emerald-600">Novos Valores:</h4>
                <pre id="audit-new-json" class="p-3 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px] overflow-x-auto text-slate-700"></pre>
            </div>
        </div>

        <div class="mt-5 pt-3 border-t border-slate-100 flex justify-end">
            <button type="button" onclick="closeAuditDetails()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-all">
                Fechar
            </button>
        </div>

    </div>
</div>

<script>
function showAuditDetails(log) {
    document.getElementById('audit-modal-subtitle').textContent = log.action + ' em ' + log.entity + ' - ' + log.description;
    
    const oldSec = document.getElementById('audit-old-section');
    const oldPre = document.getElementById('audit-old-json');
    if (log.old_values) {
        try {
            oldPre.textContent = JSON.stringify(JSON.parse(log.old_values), null, 2);
            oldSec.classList.remove('hidden');
        } catch(e) {
            oldPre.textContent = log.old_values;
            oldSec.classList.remove('hidden');
        }
    } else {
        oldSec.classList.add('hidden');
    }

    const newSec = document.getElementById('audit-new-section');
    const newPre = document.getElementById('audit-new-json');
    if (log.new_values) {
        try {
            newPre.textContent = JSON.stringify(JSON.parse(log.new_values), null, 2);
            newSec.classList.remove('hidden');
        } catch(e) {
            newPre.textContent = log.new_values;
            newSec.classList.remove('hidden');
        }
    } else {
        newSec.classList.add('hidden');
    }

    document.getElementById('audit-details-modal').classList.remove('hidden');
}

function closeAuditDetails() {
    document.getElementById('audit-details-modal').classList.add('hidden');
}
</script>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
