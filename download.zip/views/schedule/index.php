<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-6">
    
    <!-- Cabeçalho & Botão Criar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Grade Horária & Aulas Semanais</h1>
            <p class="text-sm text-slate-500">Organize os horários das suas aulas de Segunda a Domingo</p>
        </div>
        <button type="button" onclick="openScheduleModal()"
                class="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Adicionar Aula na Grade</span>
        </button>
    </div>

    <!-- Grade Semanal (Mobile-First responsive cards) -->
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <?php 
        $currentDayNum = (int)date('N');
        foreach ($days as $dayNum => $dayData): 
            $isCurrentDay = ($dayNum === $currentDayNum);
        ?>
            <div class="bg-white rounded-2xl shadow-sm border <?= $isCurrentDay ? 'border-brand-400 ring-2 ring-brand-100' : 'border-slate-200' ?> p-5 flex flex-col">
                
                <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                    <div class="flex items-center gap-2">
                        <h3 class="text-base font-bold text-slate-900"><?= e($dayData['name']) ?></h3>
                        <?php if ($isCurrentDay): ?>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-brand-600 text-white">Hoje</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-xs text-slate-400 font-medium"><?= count($dayData['classes']) ?> aula(s)</span>
                </div>

                <div class="space-y-3 flex-1">
                    <?php if (empty($dayData['classes'])): ?>
                        <div class="h-28 flex items-center justify-center text-slate-400 text-xs italic">
                            Sem aulas cadastradas
                        </div>
                    <?php else: ?>
                        <?php foreach ($dayData['classes'] as $cls): ?>
                            <div class="p-3.5 rounded-xl border border-l-4 border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3" style="border-left-color: <?= e($cls['subject_color']) ?>">
                                <div>
                                    <h4 class="text-sm font-bold text-slate-900"><?= e($cls['subject_name']) ?></h4>
                                    <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-1">
                                        <span class="font-semibold text-slate-700">
                                            <?= substr($cls['start_time'], 0, 5) ?> - <?= substr($cls['end_time'], 0, 5) ?>
                                        </span>
                                        <?php if (!empty($cls['room'])): ?>
                                            <span>&bull; Sala: <?= e($cls['room']) ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($cls['teacher'])): ?>
                                            <span>&bull; Prof. <?= e($cls['teacher']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($cls['notes'])): ?>
                                        <p class="text-[11px] text-slate-400 mt-1 italic"><?= e($cls['notes']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <form action="index.php?route=schedule/delete" method="POST"
                                      data-confirm="Deseja remover esta aula de <?= e($cls['subject_name']) ?> da sua grade?"
                                      data-title="Remover Aula">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $cls['id'] ?>">
                                    <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors" title="Excluir Horário">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Modal Personalizado para Adicionar Aula na Grade -->
<div id="schedule-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm hidden animate-fade-in">
    <div class="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-100 animate-slide-down">
        
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <h3 class="text-lg font-bold text-slate-900">Adicionar Aula na Grade</h3>
            <button type="button" onclick="closeScheduleModal()" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <form action="index.php?route=schedule/store" method="POST" class="space-y-4">
            <?= csrf_field() ?>

            <div>
                <label for="sched-sub" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Disciplina *
                </label>
                <select id="sched-sub" name="subject_id" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Selecione uma disciplina...</option>
                    <?php foreach ($subjects as $sub): ?>
                        <option value="<?= $sub['id'] ?>"><?= e($sub['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="sched-day" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Dia da Semana *
                </label>
                <select id="sched-day" name="day_of_week" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="1">Segunda-feira</option>
                    <option value="2">Terça-feira</option>
                    <option value="3">Quarta-feira</option>
                    <option value="4">Quinta-feira</option>
                    <option value="5">Sexta-feira</option>
                    <option value="6">Sábado</option>
                    <option value="7">Domingo</option>
                </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label for="sched-start" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Início *
                    </label>
                    <input type="time" id="sched-start" name="start_time" required
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                </div>
                <div>
                    <label for="sched-end" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Término *
                    </label>
                    <input type="time" id="sched-end" name="end_time" required
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                </div>
            </div>

            <div>
                <label for="sched-room" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Sala de Aula (opcional)
                </label>
                <input type="text" id="sched-room" name="room" placeholder="Ex: Laboratório 3"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div>
                <label for="sched-notes" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Observações (opcional)
                </label>
                <input type="text" id="sched-notes" name="notes" placeholder="Ex: Levar jaleco e caderno"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div class="flex items-center justify-end gap-3 pt-3">
                <button type="button" onclick="closeScheduleModal()" class="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
                    Cancelar
                </button>
                <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                    Salvar na Grade
                </button>
            </div>
        </form>

    </div>
</div>

<script>
function openScheduleModal() {
    document.getElementById('schedule-modal').classList.remove('hidden');
}
function closeScheduleModal() {
    document.getElementById('schedule-modal').classList.add('hidden');
}
</script>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
