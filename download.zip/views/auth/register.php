<?php
require __DIR__ . '/../layouts/header.php';
$old = $_SESSION['old_register'] ?? [];
unset($_SESSION['old_register']);
?>

<div class="min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
    <div class="max-w-lg w-full bg-white rounded-3xl shadow-2xl p-8 sm:p-10 border border-slate-100">
        
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 items-center justify-center text-white shadow-lg shadow-brand-500/40 mb-4">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                </svg>
            </div>
            <h1 class="text-2xl font-black tracking-tight text-slate-900">Cadastre-se no SOS-Estudante</h1>
            <p class="text-sm text-slate-500 mt-1">Crie sua conta para gerenciar notas, tarefas e aulas</p>
        </div>

        <!-- Formulário de Registro -->
        <form action="index.php?route=register" method="POST" class="space-y-4">
            <?= csrf_field() ?>

            <div>
                <label for="name" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Nome Completo *
                </label>
                <input type="text" id="name" name="name" value="<?= e($old['name'] ?? '') ?>" required autofocus
                       placeholder="Ex: Carlos Eduardo da Silva"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
            </div>

            <div>
                <label for="email" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Endereço de E-mail *
                </label>
                <input type="email" id="email" name="email" value="<?= e($old['email'] ?? '') ?>" required
                       placeholder="seu.email@escola.edu.br"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="course" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Curso / Série
                    </label>
                    <input type="text" id="course" name="course" value="<?= e($old['course'] ?? '') ?>"
                           placeholder="Ex: Engenharia de Software"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
                </div>

                <div>
                    <label for="institution" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Instituição de Ensino
                    </label>
                    <input type="text" id="institution" name="institution" value="<?= e($old['institution'] ?? '') ?>"
                           placeholder="Ex: USP, IFSP, UFMG"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="password" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Senha * (min. 6 dígitos)
                    </label>
                    <input type="password" id="password" name="password" required minlength="6"
                           placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
                </div>

                <div>
                    <label for="password_confirm" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Confirmar Senha *
                    </label>
                    <input type="password" id="password_confirm" name="password_confirm" required minlength="6"
                           placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all">
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" 
                        class="w-full py-3.5 px-4 bg-brand-600 hover:bg-brand-700 active:bg-brand-800 text-white font-semibold rounded-xl shadow-lg shadow-brand-500/30 transition-all duration-200 flex items-center justify-center gap-2">
                    <span>Criar Minha Conta</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                </button>
            </div>
        </form>

        <div class="mt-8 pt-6 border-t border-slate-100 text-center">
            <p class="text-sm text-slate-600">
                Já possui uma conta criada?
                <a href="index.php?route=login" class="font-semibold text-brand-600 hover:text-brand-700 hover:underline">
                    Fazer Login
                </a>
            </p>
        </div>

    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
