<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-8">
    <!-- Cabeçalho -->
    <div>
        <h1 class="text-2xl font-bold tracking-tight text-slate-900">Meu Perfil</h1>
        <p class="text-sm text-slate-500">Gerencie seus dados pessoais e credenciais de acesso</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <!-- Cartão de Dados Pessoais -->
        <div class="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div class="flex items-center gap-3 mb-6">
                <div class="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </div>
                <div>
                    <h2 class="text-lg font-bold text-slate-900">Informações Pessoais</h2>
                    <p class="text-xs text-slate-500">Atualize seu nome, curso e instituição de ensino</p>
                </div>
            </div>

            <form action="index.php?route=profile/update" method="POST" class="space-y-4">
                <?= csrf_field() ?>

                <div>
                    <label for="name" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Nome Completo</label>
                    <input type="text" id="name" name="name" value="<?= e($user['name']) ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">E-mail Cadastrado</label>
                    <input type="email" value="<?= e($user['email']) ?>" disabled
                           class="w-full px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-500 cursor-not-allowed">
                    <span class="text-[11px] text-slate-400 mt-1 block">O e-mail é o identificador único da sua conta e não pode ser modificado diretamente.</span>
                </div>

                <div>
                    <label for="course" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Curso / Área de Estudo</label>
                    <input type="text" id="course" name="course" value="<?= e($user['course'] ?? '') ?>"
                           placeholder="Ex: Engenharia de Computação"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label for="institution" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Instituição de Ensino</label>
                    <input type="text" id="institution" name="institution" value="<?= e($user['institution'] ?? '') ?>"
                           placeholder="Ex: Universidade de São Paulo"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div class="pt-2">
                    <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
                        Salvar Alterações
                    </button>
                </div>
            </form>
        </div>

        <!-- Cartão de Alteração de Senha -->
        <div class="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
            <div class="flex items-center gap-3 mb-6">
                <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                </div>
                <div>
                    <h2 class="text-lg font-bold text-slate-900">Segurança da Senha</h2>
                    <p class="text-xs text-slate-500">Mantenha sua senha forte com letras, números e símbolos</p>
                </div>
            </div>

            <form action="index.php?route=profile/password" method="POST" class="space-y-4">
                <?= csrf_field() ?>

                <div>
                    <label for="current_password" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Senha Atual *</label>
                    <input type="password" id="current_password" name="current_password" required
                           placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label for="new_password" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Nova Senha * (mínimo 6 caracteres)</label>
                    <input type="password" id="new_password" name="new_password" required minlength="6"
                           placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div>
                    <label for="new_password_confirm" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">Confirmar Nova Senha *</label>
                    <input type="password" id="new_password_confirm" name="new_password_confirm" required minlength="6"
                           placeholder="••••••••"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:bg-white">
                </div>

                <div class="pt-2">
                    <button type="submit" class="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                        Atualizar Senha
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
