<?php
require __DIR__ . '/../layouts/header.php';
?>

<div class="space-y-6">
    
    <!-- Cabeçalho & Botão Criar -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Disciplinas & Matérias</h1>
            <p class="text-sm text-slate-500">Organize os cursos escolares, professores e salas de aula</p>
        </div>
        <button type="button" onclick="openSubjectModal()"
                class="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-brand-500/20 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Nova Disciplina</span>
        </button>
    </div>

    <!-- Lista de Disciplinas -->
    <?php if (empty($subjects)): ?>
        <div class="bg-white rounded-3xl p-12 text-center border border-dashed border-slate-300">
            <div class="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
            </div>
            <h3 class="text-base font-bold text-slate-800">Nenhuma disciplina cadastrada</h3>
            <p class="text-xs text-slate-500 mt-1 max-w-sm mx-auto">Cadastre suas matérias para vincular às atividades e grade horária.</p>
            <div class="mt-5">
                <button type="button" onclick="openSubjectModal()" class="inline-flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs rounded-xl shadow-md transition-all">
                    Adicionar Primeira Disciplina
                </button>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <?php foreach ($subjects as $sub): ?>
                <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition-all flex flex-col justify-between">
                    <div>
                        <!-- Barra superior colorida com nome -->
                        <div class="flex items-start justify-between gap-3 mb-3">
                            <div class="flex items-center gap-2.5">
                                <span class="w-4 h-4 rounded-full flex-shrink-0" style="background-color: <?= e($sub['color']) ?>"></span>
                                <h3 class="text-base font-bold text-slate-900 leading-snug"><?= e($sub['name']) ?></h3>
                            </div>
                            <?php if (!empty($sub['code'])): ?>
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-600">
                                    <?= e($sub['code']) ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <!-- Detalhes -->
                        <div class="space-y-1.5 text-xs text-slate-600 mb-4 pl-6.5">
                            <?php if (!empty($sub['teacher'])): ?>
                                <p class="flex items-center gap-2">
                                    <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                    Prof. <?= e($sub['teacher']) ?>
                                </p>
                            <?php endif; ?>

                            <?php if (!empty($sub['classroom'])): ?>
                                <p class="flex items-center gap-2">
                                    <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                                    Sala / Local: <?= e($sub['classroom']) ?>
                                </p>
                            <?php endif; ?>

                            <p class="flex items-center gap-2 text-indigo-600 font-medium">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                                <?= (int)$sub['pending_tasks_count'] ?> atividade(s) pendente(s)
                            </p>
                        </div>
                    </div>

                    <!-- Ações -->
                    <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <a href="index.php?route=tasks&subject_id=<?= $sub['id'] ?>" class="text-xs font-semibold text-brand-600 hover:text-brand-700">
                            Ver tarefas &rarr;
                        </a>

                        <div class="flex items-center gap-1">
                            <button type="button" 
                                    onclick='editSubject(<?= json_encode($sub) ?>)'
                                    class="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-all" title="Editar">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            </button>

                            <form action="index.php?route=subjects/delete" method="POST" 
                                  data-confirm="Excluir a disciplina '<?= e($sub['name']) ?>'? Suas tarefas associadas continuarão salvas." 
                                  data-title="Excluir Disciplina">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $sub['id'] ?>">
                                <button type="submit" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Excluir">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Modal Personalizado para Criar / Editar Disciplina (Sem alerts nativos) -->
<div id="subject-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm hidden animate-fade-in">
    <div class="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-100 animate-slide-down">
        
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <h3 id="subject-modal-title" class="text-lg font-bold text-slate-900">Cadastrar Disciplina</h3>
            <button type="button" onclick="closeSubjectModal()" class="text-slate-400 hover:text-slate-600 p-1">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <form id="subject-form" action="index.php?route=subjects/store" method="POST" class="space-y-4">
            <?= csrf_field() ?>
            <input type="hidden" id="subject-id" name="id" value="">

            <div>
                <label for="modal-sub-name" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Nome da Disciplina *
                </label>
                <input type="text" id="modal-sub-name" name="name" required placeholder="Ex: Cálculo I"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label for="modal-sub-code" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Código / Sigla
                    </label>
                    <input type="text" id="modal-sub-code" name="code" placeholder="Ex: MAT101"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
                </div>
                <div>
                    <label for="modal-sub-color" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                        Cor de Destaque
                    </label>
                    <input type="color" id="modal-sub-color" name="color" value="#3B82F6"
                           class="w-full h-10 p-1 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer">
                </div>
            </div>

            <div>
                <label for="modal-sub-teacher" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Professor(a)
                </label>
                <input type="text" id="modal-sub-teacher" name="teacher" placeholder="Ex: Dra. Mariana Costa"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div>
                <label for="modal-sub-room" class="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Sala de Aula / Link
                </label>
                <input type="text" id="modal-sub-room" name="classroom" placeholder="Ex: Bloco B - Sala 204"
                       class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            </div>

            <div class="flex items-center justify-end gap-3 pt-3">
                <button type="button" onclick="closeSubjectModal()" class="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all">
                    Cancelar
                </button>
                <button type="submit" class="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm rounded-xl shadow-md transition-all">
                    Salvar Disciplina
                </button>
            </div>
        </form>

    </div>
</div>

<script>
function openSubjectModal() {
    const modal = document.getElementById('subject-modal');
    document.getElementById('subject-form').action = 'index.php?route=subjects/store';
    document.getElementById('subject-modal-title').textContent = 'Cadastrar Disciplina';
    document.getElementById('subject-id').value = '';
    document.getElementById('modal-sub-name').value = '';
    document.getElementById('modal-sub-code').value = '';
    document.getElementById('modal-sub-teacher').value = '';
    document.getElementById('modal-sub-room').value = '';
    document.getElementById('modal-sub-color').value = '#3B82F6';
    modal.classList.remove('hidden');
}

function editSubject(sub) {
    const modal = document.getElementById('subject-modal');
    document.getElementById('subject-form').action = 'index.php?route=subjects/update';
    document.getElementById('subject-modal-title').textContent = 'Editar Disciplina';
    document.getElementById('subject-id').value = sub.id;
    document.getElementById('modal-sub-name').value = sub.name;
    document.getElementById('modal-sub-code').value = sub.code || '';
    document.getElementById('modal-sub-teacher').value = sub.teacher || '';
    document.getElementById('modal-sub-room').value = sub.classroom || '';
    document.getElementById('modal-sub-color').value = sub.color || '#3B82F6';
    modal.classList.remove('hidden');
}

function closeSubjectModal() {
    document.getElementById('subject-modal').classList.add('hidden');
}
</script>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
