/**
 * SOS-Estudante - Frontend JavaScript
 * Gerenciamento de Toasts, Modais de Confirmação (sem alert/confirm nativos) e UI Mobile.
 */

// --- Sistema de Toast ---
window.Toast = {
    container: null,

    init() {
        if (!this.container) {
            let el = document.getElementById('toast-container');
            if (!el) {
                el = document.createElement('div');
                el.id = 'toast-container';
                el.className = 'fixed top-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0';
                document.body.appendChild(el);
            }
            this.container = el;
        }
    },

    show(type, message, duration = 4000) {
        this.init();

        const toast = document.createElement('div');
        toast.className = `pointer-events-auto flex items-center justify-between p-4 rounded-xl shadow-lg border text-sm font-medium transition-all duration-300 transform translate-y-[-10px] opacity-0 animate-slide-down`;

        let iconSvg = '';
        let bgClass = '';

        switch (type) {
            case 'success':
                bgClass = 'bg-emerald-50 border-emerald-200 text-emerald-800';
                iconSvg = `<svg class="w-5 h-5 text-emerald-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
                break;
            case 'error':
                bgClass = 'bg-rose-50 border-rose-200 text-rose-800';
                iconSvg = `<svg class="w-5 h-5 text-rose-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`;
                break;
            case 'warning':
                bgClass = 'bg-amber-50 border-amber-200 text-amber-800';
                iconSvg = `<svg class="w-5 h-5 text-amber-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`;
                break;
            default: // info
                bgClass = 'bg-blue-50 border-blue-200 text-blue-800';
                iconSvg = `<svg class="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;
                break;
        }

        toast.className += ` ${bgClass}`;
        toast.innerHTML = `
            <div class="flex items-center flex-1 mr-2">
                ${iconSvg}
                <span>${message}</span>
            </div>
            <button type="button" class="text-gray-400 hover:text-gray-600 focus:outline-none p-1" onclick="this.parentElement.remove()">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        `;

        this.container.appendChild(toast);

        // Animação de entrada
        setTimeout(() => {
            toast.classList.remove('translate-y-[-10px]', 'opacity-0');
        }, 10);

        // Auto remoção
        setTimeout(() => {
            toast.classList.add('opacity-0', 'scale-95');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
};

window.showToast = (type, message, duration) => window.Toast.show(type, message, duration);

// --- Sistema de Modal de Confirmação Personalizado ---
window.ConfirmModal = {
    modalEl: null,
    titleEl: null,
    messageEl: null,
    confirmBtn: null,
    cancelBtn: null,
    currentAction: null,

    init() {
        if (!this.modalEl) {
            let el = document.getElementById('global-confirm-modal');
            if (!el) {
                el = document.createElement('div');
                el.id = 'global-confirm-modal';
                el.className = 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm hidden animate-fade-in';
                el.innerHTML = `
                    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 transform transition-all animate-slide-down">
                        <div class="flex items-center gap-3 mb-4">
                            <div id="modal-icon-container" class="w-10 h-10 rounded-full flex items-center justify-center bg-rose-100 text-rose-600">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                            </div>
                            <h3 id="modal-title" class="text-lg font-bold text-gray-900">Confirmação</h3>
                        </div>
                        <p id="modal-message" class="text-sm text-gray-600 mb-6">Tem certeza que deseja prosseguir com esta ação?</p>
                        <div class="flex justify-end gap-3">
                            <button id="modal-cancel-btn" type="button" class="px-4 py-2 text-sm font-semibold text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors">
                                Cancelar
                            </button>
                            <button id="modal-confirm-btn" type="button" class="px-4 py-2 text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-colors">
                                Confirmar
                            </button>
                        </div>
                    </div>
                `;
                document.body.appendChild(el);
            }

            this.modalEl = el;
            this.titleEl = el.querySelector('#modal-title');
            this.messageEl = el.querySelector('#modal-message');
            this.confirmBtn = el.querySelector('#modal-confirm-btn');
            this.cancelBtn = el.querySelector('#modal-cancel-btn');

            this.cancelBtn.addEventListener('click', () => this.close());
            this.modalEl.addEventListener('click', (e) => {
                if (e.target === this.modalEl) this.close();
            });
        }
    },

    open({ title = 'Confirmação', message = 'Deseja prosseguir?', confirmText = 'Confirmar', cancelText = 'Cancelar', confirmColor = 'rose', onConfirm }) {
        this.init();
        this.titleEl.textContent = title;
        this.messageEl.textContent = message;
        this.confirmBtn.textContent = confirmText;
        this.cancelBtn.textContent = cancelText;

        // Estilização do botão de confirmar
        this.confirmBtn.className = `px-4 py-2 text-sm font-semibold text-white rounded-xl shadow-md transition-colors ${
            confirmColor === 'rose' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-blue-600 hover:bg-blue-700'
        }`;

        const handleConfirm = () => {
            this.close();
            if (typeof onConfirm === 'function') onConfirm();
        };

        // Remove listener anterior
        const newConfirmBtn = this.confirmBtn.cloneNode(true);
        this.confirmBtn.parentNode.replaceChild(newConfirmBtn, this.confirmBtn);
        this.confirmBtn = newConfirmBtn;
        this.confirmBtn.addEventListener('click', handleConfirm);

        this.modalEl.classList.remove('hidden');
    },

    close() {
        if (this.modalEl) {
            this.modalEl.classList.add('hidden');
        }
    }
};

window.confirmModal = (options) => window.ConfirmModal.open(options);

// Helper para interceptar formulários com confirmação
document.addEventListener('DOMContentLoaded', () => {
    // Interceptar forms de exclusão
    document.querySelectorAll('form[data-confirm]').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const message = this.getAttribute('data-confirm') || 'Tem certeza que deseja excluir este item?';
            const title = this.getAttribute('data-title') || 'Excluir Registro';
            
            window.confirmModal({
                title: title,
                message: message,
                confirmText: 'Excluir',
                confirmColor: 'rose',
                onConfirm: () => form.submit()
            });
        });
    });

    // Toggle menu mobile
    const mobileMenuBtn = document.getElementById('mobile-menu-toggle');
    const mobileSidebar = document.getElementById('mobile-sidebar');
    const mobileSidebarBackdrop = document.getElementById('mobile-sidebar-backdrop');
    const mobileCloseBtn = document.getElementById('mobile-sidebar-close');

    if (mobileMenuBtn && mobileSidebar) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileSidebar.classList.remove('-translate-x-full');
            if (mobileSidebarBackdrop) mobileSidebarBackdrop.classList.remove('hidden');
        });

        const closeMobile = () => {
            mobileSidebar.classList.add('-translate-x-full');
            if (mobileSidebarBackdrop) mobileSidebarBackdrop.classList.add('hidden');
        };

        if (mobileCloseBtn) mobileCloseBtn.addEventListener('click', closeMobile);
        if (mobileSidebarBackdrop) mobileSidebarBackdrop.addEventListener('click', closeMobile);
    }
});
