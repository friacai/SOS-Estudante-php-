<?php
/**
 * SOS-Estudante
 * Model de Usuário.
 */

require_once __DIR__ . '/../config/bd.php';

class User {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function findById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT id, name, email, institution, course, avatar, created_at FROM users WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    public function findByEmail(string $email): ?array {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => strtolower(trim($email))]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO users (name, email, password, institution, course)
            VALUES (:name, :email, :password, :institution, :course)
        ");
        $stmt->execute([
            'name' => trim($data['name']),
            'email' => strtolower(trim($data['email'])),
            'password' => $data['password'], // Hash gerado no Service
            'institution' => !empty($data['institution']) ? trim($data['institution']) : null,
            'course' => !empty($data['course']) ? trim($data['course']) : null
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function updateProfile(int $id, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET name = :name, institution = :institution, course = :course, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
        ");
        return $stmt->execute([
            'id' => $id,
            'name' => trim($data['name']),
            'institution' => !empty($data['institution']) ? trim($data['institution']) : null,
            'course' => !empty($data['course']) ? trim($data['course']) : null
        ]);
    }

    public function updatePassword(int $id, string $hashedPassword): bool {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET password = :password, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
        ");
        return $stmt->execute([
            'id' => $id,
            'password' => $hashedPassword
        ]);
    }
}
