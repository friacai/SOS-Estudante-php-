<?php
/**
 * SOS-Estudante
 * Model de Anotações e Lembretes Rápidos.
 */

require_once __DIR__ . '/../config/bd.php';

class Note {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAllByUser(int $userId, ?string $search = null): array {
        $sql = "SELECT * FROM notes WHERE user_id = :user_id";
        $params = ['user_id' => $userId];

        if (!empty($search)) {
            $sql .= " AND (title LIKE :search OR content LIKE :search)";
            $params['search'] = '%' . trim($search) . '%';
        }

        $sql .= " ORDER BY is_pinned DESC, updated_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getById(int $id, int $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM notes WHERE id = :id AND user_id = :user_id LIMIT 1");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO notes (user_id, title, content, color, is_pinned)
            VALUES (:user_id, :title, :content, :color, :is_pinned)
        ");
        $stmt->execute([
            'user_id' => (int)$data['user_id'],
            'title' => trim($data['title']),
            'content' => trim($data['content']),
            'color' => !empty($data['color']) ? trim($data['color']) : '#F59E0B',
            'is_pinned' => !empty($data['is_pinned']) ? 1 : 0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE notes 
            SET title = :title, content = :content, color = :color, is_pinned = :is_pinned, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id AND user_id = :user_id
        ");
        return $stmt->execute([
            'id' => $id,
            'user_id' => $userId,
            'title' => trim($data['title']),
            'content' => trim($data['content']),
            'color' => !empty($data['color']) ? trim($data['color']) : '#F59E0B',
            'is_pinned' => !empty($data['is_pinned']) ? 1 : 0
        ]);
    }

    public function togglePin(int $id, int $userId): bool {
        $note = $this->getById($id, $userId);
        if (!$note) return false;
        $newPinned = $note['is_pinned'] ? 0 : 1;
        $stmt = $this->db->prepare("UPDATE notes SET is_pinned = :p, updated_at = CURRENT_TIMESTAMP WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['p' => $newPinned, 'id' => $id, 'user_id' => $userId]);
    }

    public function delete(int $id, int $userId): bool {
        $stmt = $this->db->prepare("DELETE FROM notes WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['id' => $id, 'user_id' => $userId]);
    }
}
