<?php
/**
 * SOS-Estudante
 * Model de Matéria / Disciplina.
 */

require_once __DIR__ . '/../config/bd.php';

class Subject {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAllByUser(int $userId): array {
        $stmt = $this->db->prepare("
            SELECT s.*, 
                   (SELECT COUNT(*) FROM tasks t WHERE t.subject_id = s.id AND t.status != 'Concluída') as pending_tasks_count
            FROM subjects s 
            WHERE s.user_id = :user_id 
            ORDER BY s.name ASC
        ");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    public function getById(int $id, int $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM subjects WHERE id = :id AND user_id = :user_id LIMIT 1");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        $sub = $stmt->fetch();
        return $sub ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO subjects (user_id, name, code, teacher, classroom, color)
            VALUES (:user_id, :name, :code, :teacher, :classroom, :color)
        ");
        $stmt->execute([
            'user_id' => (int)$data['user_id'],
            'name' => trim($data['name']),
            'code' => !empty($data['code']) ? trim($data['code']) : null,
            'teacher' => !empty($data['teacher']) ? trim($data['teacher']) : null,
            'classroom' => !empty($data['classroom']) ? trim($data['classroom']) : null,
            'color' => !empty($data['color']) ? trim($data['color']) : '#3B82F6'
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE subjects 
            SET name = :name, code = :code, teacher = :teacher, classroom = :classroom, color = :color, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id AND user_id = :user_id
        ");
        return $stmt->execute([
            'id' => $id,
            'user_id' => $userId,
            'name' => trim($data['name']),
            'code' => !empty($data['code']) ? trim($data['code']) : null,
            'teacher' => !empty($data['teacher']) ? trim($data['teacher']) : null,
            'classroom' => !empty($data['classroom']) ? trim($data['classroom']) : null,
            'color' => !empty($data['color']) ? trim($data['color']) : '#3B82F6'
        ]);
    }

    public function delete(int $id, int $userId): bool {
        $stmt = $this->db->prepare("DELETE FROM subjects WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['id' => $id, 'user_id' => $userId]);
    }

    public function countByUser(int $userId): int {
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM subjects WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $userId]);
        $row = $stmt->fetch();
        return (int)($row['total'] ?? 0);
    }
}
