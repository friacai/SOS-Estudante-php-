<?php
/**
 * SOS-Estudante
 * Model de Grade Horária e Aulas.
 */

require_once __DIR__ . '/../config/bd.php';

class Schedule {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAllByUser(int $userId): array {
        $stmt = $this->db->prepare("
            SELECT sch.*, s.name as subject_name, s.color as subject_color, s.teacher, s.classroom as default_room
            FROM schedules sch
            JOIN subjects s ON sch.subject_id = s.id
            WHERE sch.user_id = :user_id
            ORDER BY sch.day_of_week ASC, sch.start_time ASC
        ");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    public function getByUserAndDay(int $userId, int $dayOfWeek): array {
        $stmt = $this->db->prepare("
            SELECT sch.*, s.name as subject_name, s.color as subject_color, s.teacher, s.classroom as default_room
            FROM schedules sch
            JOIN subjects s ON sch.subject_id = s.id
            WHERE sch.user_id = :user_id AND sch.day_of_week = :day
            ORDER BY sch.start_time ASC
        ");
        $stmt->execute(['user_id' => $userId, 'day' => $dayOfWeek]);
        return $stmt->fetchAll();
    }

    public function getById(int $id, int $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM schedules WHERE id = :id AND user_id = :user_id LIMIT 1");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO schedules (user_id, subject_id, day_of_week, start_time, end_time, room, notes)
            VALUES (:user_id, :subject_id, :day_of_week, :start_time, :end_time, :room, :notes)
        ");
        $stmt->execute([
            'user_id' => (int)$data['user_id'],
            'subject_id' => (int)$data['subject_id'],
            'day_of_week' => (int)$data['day_of_week'],
            'start_time' => $data['start_time'],
            'end_time' => $data['end_time'],
            'room' => !empty($data['room']) ? trim($data['room']) : null,
            'notes' => !empty($data['notes']) ? trim($data['notes']) : null
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function delete(int $id, int $userId): bool {
        $stmt = $this->db->prepare("DELETE FROM schedules WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['id' => $id, 'user_id' => $userId]);
    }
}
