<?php
/**
 * SOS-Estudante
 * Model de Auditoria e Histórico de Operações (Requisitos Seção 3.3).
 * Registros imutáveis para integridade e rastreabilidade.
 */

require_once __DIR__ . '/../config/bd.php';

class AuditLog {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Registra uma operação no histórico de auditoria.
     */
    public function log(
        int $userId, 
        string $action, 
        string $entity, 
        ?int $entityId, 
        string $description, 
        ?array $oldValues = null, 
        ?array $newValues = null
    ): bool {
        try {
            // Sanitização de segurança: remove senhas ou tokens
            if ($oldValues) {
                unset($oldValues['password'], $oldValues['csrf_token'], $oldValues['token']);
            }
            if ($newValues) {
                unset($newValues['password'], $newValues['csrf_token'], $newValues['token']);
            }

            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido', 0, 250);

            $stmt = $this->db->prepare("
                INSERT INTO audit_logs (user_id, action, entity, entity_id, description, old_values, new_values, ip_address, user_agent)
                VALUES (:user_id, :action, :entity, :entity_id, :description, :old_values, :new_values, :ip_address, :user_agent)
            ");

            return $stmt->execute([
                'user_id' => $userId,
                'action' => strtoupper(trim($action)),
                'entity' => strtolower(trim($entity)),
                'entity_id' => $entityId,
                'description' => trim($description),
                'old_values' => !empty($oldValues) ? json_encode($oldValues, JSON_UNESCAPED_UNICODE) : null,
                'new_values' => !empty($newValues) ? json_encode($newValues, JSON_UNESCAPED_UNICODE) : null,
                'ip_address' => $ip,
                'user_agent' => $userAgent
            ]);
        } catch (Exception $e) {
            // Falha não interrompe a operação principal, mas é registrada no log de arquivo
            @file_put_contents(
                __DIR__ . '/../logs/app.log', 
                "[" . date('Y-m-d H:i:s') . "] [ERROR] Falha ao registrar log de auditoria: " . $e->getMessage() . PHP_EOL, 
                FILE_APPEND
            );
            return false;
        }
    }

    /**
     * Consulta o histórico de operações do usuário com filtros e paginação.
     */
    public function getAllByUser(int $userId, array $filters = [], int $limit = 50, int $offset = 0): array {
        $sql = "SELECT * FROM audit_logs WHERE user_id = :user_id";
        $params = ['user_id' => $userId];

        if (!empty($filters['action'])) {
            $sql .= " AND action = :action";
            $params['action'] = strtoupper(trim($filters['action']));
        }

        if (!empty($filters['entity'])) {
            $sql .= " AND entity = :entity";
            $params['entity'] = strtolower(trim($filters['entity']));
        }

        if (!empty($filters['search'])) {
            $sql .= " AND description LIKE :search";
            $params['search'] = '%' . trim($filters['search']) . '%';
        }

        if (!empty($filters['date_from'])) {
            $sql .= " AND created_at >= :date_from";
            $params['date_from'] = $filters['date_from'] . ' 00:00:00';
        }

        if (!empty($filters['date_to'])) {
            $sql .= " AND created_at <= :date_to";
            $params['date_to'] = $filters['date_to'] . ' 23:59:59';
        }

        $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue(':' . $k, $v);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function countByUser(int $userId, array $filters = []): int {
        $sql = "SELECT COUNT(*) as total FROM audit_logs WHERE user_id = :user_id";
        $params = ['user_id' => $userId];

        if (!empty($filters['action'])) {
            $sql .= " AND action = :action";
            $params['action'] = strtoupper(trim($filters['action']));
        }

        if (!empty($filters['entity'])) {
            $sql .= " AND entity = :entity";
            $params['entity'] = strtolower(trim($filters['entity']));
        }

        if (!empty($filters['search'])) {
            $sql .= " AND description LIKE :search";
            $params['search'] = '%' . trim($filters['search']) . '%';
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return (int)($row['total'] ?? 0);
    }
}
