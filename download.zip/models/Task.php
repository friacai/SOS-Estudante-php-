<?php
/**
 * SOS-Estudante
 * Model de Atividades e Tarefas Acadêmicas.
 */

require_once __DIR__ . '/../config/bd.php';

class Task {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAllByUser(int $userId, array $filters = []): array {
        $sql = "
            SELECT t.*, s.name as subject_name, s.color as subject_color
            FROM tasks t
            LEFT JOIN subjects s ON t.subject_id = s.id
            WHERE t.user_id = :user_id
        ";
        $params = ['user_id' => $userId];

        if (!empty($filters['status'])) {
            $sql .= " AND t.status = :status";
            $params['status'] = $filters['status'];
        }

        if (!empty($filters['priority'])) {
            $sql .= " AND t.priority = :priority";
            $params['priority'] = $filters['priority'];
        }

        if (!empty($filters['type'])) {
            $sql .= " AND t.type = :type";
            $params['type'] = $filters['type'];
        }

        if (!empty($filters['subject_id'])) {
            $sql .= " AND t.subject_id = :subject_id";
            $params['subject_id'] = (int)$filters['subject_id'];
        }

        if (!empty($filters['search'])) {
            $sql .= " AND (t.title LIKE :search OR t.description LIKE :search)";
            $params['search'] = '%' . trim($filters['search']) . '%';
        }

        // Ordenação
        $sort = $filters['sort'] ?? 'due_date_asc';
        switch ($sort) {
            case 'due_date_desc':
                $sql .= " ORDER BY t.due_date DESC, t.due_time DESC";
                break;
            case 'priority_desc':
                $sql .= " ORDER BY CASE t.priority 
                            WHEN 'Urgente' THEN 1 
                            WHEN 'Alta' THEN 2 
                            WHEN 'Média' THEN 3 
                            WHEN 'Baixa' THEN 4 
                            ELSE 5 END ASC, t.due_date ASC";
                break;
            case 'created_desc':
                $sql .= " ORDER BY t.created_at DESC";
                break;
            case 'due_date_asc':
            default:
                // Concluídas vão para o final
                $sql .= " ORDER BY CASE WHEN t.status = 'Concluída' THEN 1 ELSE 0 END ASC, t.due_date ASC, t.due_time ASC";
                break;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getById(int $id, int $userId): ?array {
        $stmt = $this->db->prepare("
            SELECT t.*, s.name as subject_name, s.color as subject_color
            FROM tasks t
            LEFT JOIN subjects s ON t.subject_id = s.id
            WHERE t.id = :id AND t.user_id = :user_id
            LIMIT 1
        ");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        $task = $stmt->fetch();
        return $task ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO tasks (user_id, subject_id, title, description, type, priority, status, due_date, due_time)
            VALUES (:user_id, :subject_id, :title, :description, :type, :priority, :status, :due_date, :due_time)
        ");
        $stmt->execute([
            'user_id' => (int)$data['user_id'],
            'subject_id' => !empty($data['subject_id']) ? (int)$data['subject_id'] : null,
            'title' => trim($data['title']),
            'description' => !empty($data['description']) ? trim($data['description']) : null,
            'type' => $data['type'] ?? 'Tarefa',
            'priority' => $data['priority'] ?? 'Média',
            'status' => $data['status'] ?? 'Pendente',
            'due_date' => $data['due_date'],
            'due_time' => !empty($data['due_time']) ? $data['due_time'] : null
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE tasks 
            SET subject_id = :subject_id,
                title = :title,
                description = :description,
                type = :type,
                priority = :priority,
                status = :status,
                due_date = :due_date,
                due_time = :due_time,
                completed_at = :completed_at,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = :id AND user_id = :user_id
        ");
        $completedAt = ($data['status'] === 'Concluída') ? date('Y-m-d H:i:s') : null;
        return $stmt->execute([
            'id' => $id,
            'user_id' => $userId,
            'subject_id' => !empty($data['subject_id']) ? (int)$data['subject_id'] : null,
            'title' => trim($data['title']),
            'description' => !empty($data['description']) ? trim($data['description']) : null,
            'type' => $data['type'] ?? 'Tarefa',
            'priority' => $data['priority'] ?? 'Média',
            'status' => $data['status'] ?? 'Pendente',
            'due_date' => $data['due_date'],
            'due_time' => !empty($data['due_time']) ? $data['due_time'] : null,
            'completed_at' => $completedAt
        ]);
    }

    public function toggleStatus(int $id, int $userId): ?string {
        $task = $this->getById($id, $userId);
        if (!$task) {
            return null;
        }

        $newStatus = ($task['status'] === 'Concluída') ? 'Pendente' : 'Concluída';
        $completedAt = ($newStatus === 'Concluída') ? date('Y-m-d H:i:s') : null;

        $stmt = $this->db->prepare("
            UPDATE tasks 
            SET status = :status, completed_at = :completed_at, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id AND user_id = :user_id
        ");
        $stmt->execute([
            'id' => $id,
            'user_id' => $userId,
            'status' => $newStatus,
            'completed_at' => $completedAt
        ]);

        return $newStatus;
    }

    public function delete(int $id, int $userId): bool {
        $stmt = $this->db->prepare("DELETE FROM tasks WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['id' => $id, 'user_id' => $userId]);
    }

    public function getUpcoming(int $userId, int $limit = 5): array {
        $stmt = $this->db->prepare("
            SELECT t.*, s.name as subject_name, s.color as subject_color
            FROM tasks t
            LEFT JOIN subjects s ON t.subject_id = s.id
            WHERE t.user_id = :user_id AND t.status != 'Concluída'
            ORDER BY t.due_date ASC, t.due_time ASC
            LIMIT :limit
        ");
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getStats(int $userId): array {
        $today = date('Y-m-d');
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Concluída' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status != 'Concluída' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status != 'Concluída' AND (priority = 'Urgente' OR priority = 'Alta') THEN 1 ELSE 0 END) as high_priority,
                SUM(CASE WHEN status != 'Concluída' AND due_date = :today THEN 1 ELSE 0 END) as due_today,
                SUM(CASE WHEN status != 'Concluída' AND due_date < :today2 THEN 1 ELSE 0 END) as overdue
            FROM tasks
            WHERE user_id = :user_id
        ");
        $stmt->execute([
            'user_id' => $userId,
            'today' => $today,
            'today2' => $today
        ]);
        $row = $stmt->fetch();
        return [
            'total' => (int)($row['total'] ?? 0),
            'completed' => (int)($row['completed'] ?? 0),
            'pending' => (int)($row['pending'] ?? 0),
            'high_priority' => (int)($row['high_priority'] ?? 0),
            'due_today' => (int)($row['due_today'] ?? 0),
            'overdue' => (int)($row['overdue'] ?? 0)
        ];
    }
}
