<?php
/**
 * SOS-Estudante
 * Definição das Rotas Web.
 */

require_once __DIR__ . '/Router.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/DashboardController.php';
require_once __DIR__ . '/../controllers/TaskController.php';
require_once __DIR__ . '/../controllers/SubjectController.php';
require_once __DIR__ . '/../controllers/ScheduleController.php';
require_once __DIR__ . '/../controllers/NoteController.php';
require_once __DIR__ . '/../controllers/HistoryController.php';

$router = new Router();

// Rotas de Autenticação (Públicas / Visitantes)
$router->get('login', [AuthController::class, 'showLogin']);
$router->post('login', [AuthController::class, 'processLogin']);
$router->get('register', [AuthController::class, 'showRegister']);
$router->post('register', [AuthController::class, 'processRegister']);
$router->get('logout', [AuthController::class, 'logout']);

// Rotas Privadas / Estudante
$router->get('dashboard', [DashboardController::class, 'index']);

// Perfil
$router->get('profile', [AuthController::class, 'showProfile']);
$router->post('profile/update', [AuthController::class, 'updateProfile']);
$router->post('profile/password', [AuthController::class, 'updatePassword']);

// Atividades / Tarefas
$router->get('tasks', [TaskController::class, 'index']);
$router->get('tasks/create', [TaskController::class, 'create']);
$router->post('tasks/store', [TaskController::class, 'store']);
$router->get('tasks/edit', [TaskController::class, 'edit']);
$router->post('tasks/update', [TaskController::class, 'update']);
$router->post('tasks/toggle', [TaskController::class, 'toggle']);
$router->post('tasks/delete', [TaskController::class, 'delete']);

// Disciplinas / Matérias
$router->get('subjects', [SubjectController::class, 'index']);
$router->post('subjects/store', [SubjectController::class, 'store']);
$router->post('subjects/update', [SubjectController::class, 'update']);
$router->post('subjects/delete', [SubjectController::class, 'delete']);

// Grade Horária / Aulas
$router->get('schedule', [ScheduleController::class, 'index']);
$router->post('schedule/store', [ScheduleController::class, 'store']);
$router->post('schedule/delete', [ScheduleController::class, 'delete']);

// Anotações
$router->get('notes', [NoteController::class, 'index']);
$router->post('notes/store', [NoteController::class, 'store']);
$router->post('notes/update', [NoteController::class, 'update']);
$router->post('notes/pin', [NoteController::class, 'togglePin']);
$router->post('notes/delete', [NoteController::class, 'delete']);

// Histórico e Auditoria (Requisitos Seção 3.3)
$router->get('history', [HistoryController::class, 'index']);

return $router;
