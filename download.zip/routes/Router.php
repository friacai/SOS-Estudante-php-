<?php
/**
 * SOS-Estudante
 * Sistema de Roteamento Simples e Seguro.
 */

require_once __DIR__ . '/../middlewares/CsrfMiddleware.php';

class Router {
    private array $routes = [];

    public function get(string $path, array $handler): void {
        $this->routes['GET'][$path] = $handler;
    }

    public function post(string $path, array $handler): void {
        $this->routes['POST'][$path] = $handler;
    }

    public function dispatch(): void {
        $method = $_SERVER['REQUEST_METHOD'];
        $route = $_GET['route'] ?? 'dashboard';
        $route = trim($route, '/');

        // Se rota estiver vazia, direciona para dashboard ou login
        if ($route === '') {
            $route = !empty($_SESSION['user_id']) ? 'dashboard' : 'login';
        }

        // Validação CSRF obrigatória para POST
        if ($method === 'POST') {
            CsrfMiddleware::validate();
        }

        if (isset($this->routes[$method][$route])) {
            [$controllerClass, $action] = $this->routes[$method][$route];
            
            try {
                $controller = new $controllerClass();
                if (method_exists($controller, $action)) {
                    $controller->$action();
                    return;
                }
            } catch (Throwable $e) {
                log_system('CRITICAL', "Exceção não tratada na rota [{$method}] {$route}: " . $e->getMessage(), [
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ]);
                http_response_code(500);
                require __DIR__ . '/../views/errors/500.php';
                return;
            }
        }

        // 404 Não encontrado
        http_response_code(404);
        require __DIR__ . '/../views/errors/404.php';
    }
}
