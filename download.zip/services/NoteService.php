<?php
/**
 * SOS-Estudante
 * Service de Anotações e Lembretes.
 */

require_once __DIR__ . '/../models/Note.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class NoteService {
    private Note $noteModel;
    private AuditLog $auditModel;

    public function __construct() {
        $this->noteModel = new Note();
        $this->auditModel = new AuditLog();
    }

    public function listNotes(int $userId, ?string $search = null): array {
        return $this->noteModel->getAllByUser($userId, $search);
    }

    public function getNote(int $id, int $userId): ?array {
        return $this->noteModel->getById($id, $userId);
    }

    public function createNote(int $userId, array $data): array {
        $title = trim($data['title'] ?? '');
        $content = trim($data['content'] ?? '');

        if (empty($title)) {
            return ['success' => false, 'error' => 'O título da anotação é obrigatório.'];
        }

        if (empty($content)) {
            return ['success' => false, 'error' => 'O conteúdo da anotação não pode ficar vazio.'];
        }

        try {
            $id = $this->noteModel->create([
                'user_id' => $userId,
                'title' => $title,
                'content' => $content,
                'color' => $data['color'] ?? '#F59E0B',
                'is_pinned' => !empty($data['is_pinned']) ? 1 : 0
            ]);

            $this->auditModel->log(
                $userId,
                'CREATE',
                'nota',
                $id,
                "Criou a anotação '{$title}'"
            );

            return ['success' => true, 'id' => $id];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao criar nota: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao salvar anotação.'];
        }
    }

    public function updateNote(int $id, int $userId, array $data): array {
        $existing = $this->noteModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Anotação não encontrada.'];
        }

        $title = trim($data['title'] ?? '');
        $content = trim($data['content'] ?? '');

        if (empty($title)) {
            return ['success' => false, 'error' => 'O título é obrigatório.'];
        }

        try {
            $this->noteModel->update($id, $userId, [
                'title' => $title,
                'content' => $content,
                'color' => $data['color'] ?? '#F59E0B',
                'is_pinned' => !empty($data['is_pinned']) ? 1 : 0
            ]);

            $this->auditModel->log(
                $userId,
                'UPDATE',
                'nota',
                $id,
                "Atualizou a anotação '{$title}'"
            );

            return ['success' => true];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao atualizar nota {$id}: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao atualizar anotação.'];
        }
    }

    public function togglePin(int $id, int $userId): array {
        $existing = $this->noteModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Anotação não encontrada.'];
        }

        $this->noteModel->togglePin($id, $userId);
        return ['success' => true];
    }

    public function deleteNote(int $id, int $userId): array {
        $existing = $this->noteModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Anotação não encontrada.'];
        }

        $this->noteModel->delete($id, $userId);

        $this->auditModel->log(
            $userId,
            'DELETE',
            'nota',
            $id,
            "Excluiu a anotação '{$existing['title']}'"
        );

        return ['success' => true];
    }
}
