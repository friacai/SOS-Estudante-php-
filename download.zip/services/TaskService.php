<?php
/**
 * SOS-Estudante
 * Service de Tarefas e Atividades Acadêmicas.
 */

require_once __DIR__ . '/../models/Task.php';
require_once __DIR__ . '/../models/Subject.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class TaskService {
    private Task $taskModel;
    private Subject $subjectModel;
    private AuditLog $auditModel;

    public function __construct() {
        $this->taskModel = new Task();
        $this->subjectModel = new Subject();
        $this->auditModel = new AuditLog();
    }

    public function listTasks(int $userId, array $filters = []): array {
        return $this->taskModel->getAllByUser($userId, $filters);
    }

    public function getTask(int $id, int $userId): ?array {
        return $this->taskModel->getById($id, $userId);
    }

    public function createTask(int $userId, array $data): array {
        $title = trim($data['title'] ?? '');
        $dueDate = trim($data['due_date'] ?? '');
        $priority = $data['priority'] ?? 'Média';
        $type = $data['type'] ?? 'Trabalho';
        $status = $data['status'] ?? 'Pendente';
        $subjectId = !empty($data['subject_id']) ? (int)$data['subject_id'] : null;

        if (empty($title)) {
            return ['success' => false, 'error' => 'O título da atividade é obrigatório.'];
        }

        if (empty($dueDate)) {
            return ['success' => false, 'error' => 'A data de entrega é obrigatória.'];
        }

        // Valida se a matéria informada pertence ao usuário
        if ($subjectId !== null) {
            $sub = $this->subjectModel->getById($subjectId, $userId);
            if (!$sub) {
                return ['success' => false, 'error' => 'Disciplina informada não é válida para este usuário.'];
            }
        }

        $validPriorities = ['Baixa', 'Média', 'Alta', 'Urgente'];
        if (!in_array($priority, $validPriorities)) {
            $priority = 'Média';
        }

        $validStatuses = ['Pendente', 'Em Andamento', 'Concluída'];
        if (!in_array($status, $validStatuses)) {
            $status = 'Pendente';
        }

        try {
            $taskId = $this->taskModel->create([
                'user_id' => $userId,
                'subject_id' => $subjectId,
                'title' => $title,
                'description' => $data['description'] ?? null,
                'type' => $type,
                'priority' => $priority,
                'status' => $status,
                'due_date' => $dueDate,
                'due_time' => !empty($data['due_time']) ? $data['due_time'] : null
            ]);

            // Auditoria
            $this->auditModel->log(
                $userId,
                'CREATE',
                'tarefa',
                $taskId,
                "Criou a atividade '{$title}' (Prazo: {$dueDate})",
                null,
                ['title' => $title, 'priority' => $priority, 'status' => $status, 'due_date' => $dueDate]
            );

            return ['success' => true, 'taskId' => $taskId];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao criar atividade: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao salvar a atividade.'];
        }
    }

    public function updateTask(int $id, int $userId, array $data): array {
        $existing = $this->taskModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Atividade não encontrada.'];
        }

        $title = trim($data['title'] ?? '');
        $dueDate = trim($data['due_date'] ?? '');
        $priority = $data['priority'] ?? 'Média';
        $type = $data['type'] ?? 'Trabalho';
        $status = $data['status'] ?? 'Pendente';
        $subjectId = !empty($data['subject_id']) ? (int)$data['subject_id'] : null;

        if (empty($title)) {
            return ['success' => false, 'error' => 'O título da atividade é obrigatório.'];
        }

        if (empty($dueDate)) {
            return ['success' => false, 'error' => 'A data de entrega é obrigatória.'];
        }

        if ($subjectId !== null) {
            $sub = $this->subjectModel->getById($subjectId, $userId);
            if (!$sub) {
                return ['success' => false, 'error' => 'Disciplina informada não é válida.'];
            }
        }

        try {
            $this->taskModel->update($id, $userId, [
                'subject_id' => $subjectId,
                'title' => $title,
                'description' => $data['description'] ?? null,
                'type' => $type,
                'priority' => $priority,
                'status' => $status,
                'due_date' => $dueDate,
                'due_time' => !empty($data['due_time']) ? $data['due_time'] : null
            ]);

            // Auditoria
            $this->auditModel->log(
                $userId,
                'UPDATE',
                'tarefa',
                $id,
                "Atualizou a atividade '{$title}'",
                ['title' => $existing['title'], 'status' => $existing['status'], 'due_date' => $existing['due_date']],
                ['title' => $title, 'status' => $status, 'due_date' => $dueDate]
            );

            return ['success' => true];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao atualizar atividade {$id}: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao atualizar a atividade.'];
        }
    }

    public function toggleStatus(int $id, int $userId): array {
        $existing = $this->taskModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Atividade não encontrada.'];
        }

        $newStatus = $this->taskModel->toggleStatus($id, $userId);
        if ($newStatus) {
            $action = ($newStatus === 'Concluída') ? 'COMPLETE' : 'REOPEN';
            $this->auditModel->log(
                $userId,
                $action,
                'tarefa',
                $id,
                "Marcou atividade '{$existing['title']}' como {$newStatus}",
                ['status' => $existing['status']],
                ['status' => $newStatus]
            );
            return ['success' => true, 'newStatus' => $newStatus];
        }

        return ['success' => false, 'error' => 'Não foi possível alterar o status.'];
    }

    public function deleteTask(int $id, int $userId): array {
        $existing = $this->taskModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Atividade não encontrada.'];
        }

        $this->taskModel->delete($id, $userId);

        $this->auditModel->log(
            $userId,
            'DELETE',
            'tarefa',
            $id,
            "Excluiu a atividade '{$existing['title']}'",
            ['title' => $existing['title'], 'due_date' => $existing['due_date']]
        );

        return ['success' => true];
    }
}
