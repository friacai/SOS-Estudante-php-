<?php
/**
 * SOS-Estudante
 * Service de Autenticação e Gestão de Usuários.
 */

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class AuthService {
    private User $userModel;
    private AuditLog $auditModel;

    public function __construct() {
        $this->userModel = new User();
        $this->auditModel = new AuditLog();
    }

    /**
     * Registra novo usuário
     */
    public function register(array $data): array {
        $name = trim($data['name'] ?? '');
        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';
        $passwordConfirm = $data['password_confirm'] ?? '';
        $institution = trim($data['institution'] ?? '');
        $course = trim($data['course'] ?? '');

        // Validações
        if (empty($name) || strlen($name) < 3) {
            return ['success' => false, 'error' => 'O nome completo deve conter pelo menos 3 caracteres.'];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Por favor, informe um endereço de e-mail válido.'];
        }

        if (strlen($password) < 6) {
            return ['success' => false, 'error' => 'A senha deve conter no mínimo 6 caracteres.'];
        }

        if ($password !== $passwordConfirm) {
            return ['success' => false, 'error' => 'A confirmação de senha não confere.'];
        }

        // Verifica duplicidade de e-mail
        if ($this->userModel->findByEmail($email)) {
            return ['success' => false, 'error' => 'Este e-mail já está cadastrado no sistema.'];
        }

        // Criptografia segura com password_hash()
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            $userId = $this->userModel->create([
                'name' => $name,
                'email' => $email,
                'password' => $hashedPassword,
                'institution' => $institution,
                'course' => $course
            ]);

            // Auditoria
            $this->auditModel->log(
                $userId,
                'REGISTER',
                'usuario',
                $userId,
                "Usuário '{$name}' cadastrou-se no sistema.",
                null,
                ['name' => $name, 'email' => $email, 'course' => $course]
            );

            log_system('INFO', "Novo usuário registrado com ID: {$userId}");

            return ['success' => true, 'userId' => $userId];
        } catch (Exception $e) {
            log_system('ERROR', "Erro no cadastro de usuário: " . $e->getMessage());
            return ['success' => false, 'error' => 'Não foi possível concluir o cadastro. Tente novamente mais tarde.'];
        }
    }

    /**
     * Autenticação de Usuário
     */
    public function login(string $email, string $password): array {
        $email = trim($email);

        if (empty($email) || empty($password)) {
            return ['success' => false, 'error' => 'Preencha o e-mail e a senha.'];
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            return ['success' => false, 'error' => 'Credenciais inválidas. Verifique seu e-mail e senha.'];
        }

        // Verificação segura com password_verify()
        if (!password_verify($password, $user['password'])) {
            return ['success' => false, 'error' => 'Credenciais inválidas. Verifique seu e-mail e senha.'];
        }

        // Previne Session Fixation Attack regenerando a sessão
        if (!headers_sent()) {
            session_regenerate_id(true);
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_course'] = $user['course'];
        $_SESSION['user_institution'] = $user['institution'];

        // Auditoria
        $this->auditModel->log(
            $user['id'],
            'LOGIN',
            'usuario',
            $user['id'],
            "Usuário realizou login com sucesso."
        );

        log_system('INFO', "Usuário {$user['id']} realizou login.");

        return ['success' => true, 'user' => $user];
    }

    /**
     * Encerramento de sessão
     */
    public function logout(): void {
        if (!empty($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            $this->auditModel->log(
                $userId,
                'LOGOUT',
                'usuario',
                $userId,
                "Usuário realizou logout do sistema."
            );
            log_system('INFO', "Usuário {$userId} realizou logout.");
        }

        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    /**
     * Atualização do Perfil
     */
    public function updateProfile(int $userId, array $data): array {
        $name = trim($data['name'] ?? '');
        $institution = trim($data['institution'] ?? '');
        $course = trim($data['course'] ?? '');

        if (empty($name) || strlen($name) < 3) {
            return ['success' => false, 'error' => 'O nome completo deve conter pelo menos 3 caracteres.'];
        }

        $currentUser = $this->userModel->findById($userId);
        if (!$currentUser) {
            return ['success' => false, 'error' => 'Usuário não encontrado.'];
        }

        $this->userModel->updateProfile($userId, [
            'name' => $name,
            'institution' => $institution,
            'course' => $course
        ]);

        $_SESSION['user_name'] = $name;
        $_SESSION['user_institution'] = $institution;
        $_SESSION['user_course'] = $course;

        $this->auditModel->log(
            $userId,
            'UPDATE',
            'usuario',
            $userId,
            "Perfil atualizado.",
            ['name' => $currentUser['name'], 'course' => $currentUser['course']],
            ['name' => $name, 'course' => $course]
        );

        return ['success' => true];
    }

    /**
     * Alteração de Senha
     */
    public function updatePassword(int $userId, string $currentPassword, string $newPassword, string $newPasswordConfirm): array {
        if (strlen($newPassword) < 6) {
            return ['success' => false, 'error' => 'A nova senha deve ter no mínimo 6 caracteres.'];
        }

        if ($newPassword !== $newPasswordConfirm) {
            return ['success' => false, 'error' => 'A confirmação da nova senha não confere.'];
        }

        $user = $this->userModel->findById($userId);
        // Precisamos buscar com senha para verificar
        $stmt = Database::getConnection()->prepare("SELECT password FROM users WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $userId]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($currentPassword, $row['password'])) {
            return ['success' => false, 'error' => 'A senha atual está incorreta.'];
        }

        $newHashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $this->userModel->updatePassword($userId, $newHashed);

        $this->auditModel->log(
            $userId,
            'UPDATE_PASSWORD',
            'usuario',
            $userId,
            "Senha de acesso alterada com sucesso."
        );

        return ['success' => true];
    }
}
