<?php
/**
 * SOS-Estudante
 * Service de Matérias e Disciplinas.
 */

require_once __DIR__ . '/../models/Subject.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class SubjectService {
    private Subject $subjectModel;
    private AuditLog $auditModel;

    public function __construct() {
        $this->subjectModel = new Subject();
        $this->auditModel = new AuditLog();
    }

    public function listSubjects(int $userId): array {
        return $this->subjectModel->getAllByUser($userId);
    }

    public function getSubject(int $id, int $userId): ?array {
        return $this->subjectModel->getById($id, $userId);
    }

    public function createSubject(int $userId, array $data): array {
        $name = trim($data['name'] ?? '');
        $color = trim($data['color'] ?? '#3B82F6');

        if (empty($name)) {
            return ['success' => false, 'error' => 'O nome da disciplina é obrigatório.'];
        }

        try {
            $id = $this->subjectModel->create([
                'user_id' => $userId,
                'name' => $name,
                'code' => $data['code'] ?? null,
                'teacher' => $data['teacher'] ?? null,
                'classroom' => $data['classroom'] ?? null,
                'color' => $color
            ]);

            $this->auditModel->log(
                $userId,
                'CREATE',
                'materia',
                $id,
                "Cadastrou a disciplina '{$name}'",
                null,
                ['name' => $name, 'color' => $color]
            );

            return ['success' => true, 'id' => $id];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao criar matéria: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao salvar a disciplina.'];
        }
    }

    public function updateSubject(int $id, int $userId, array $data): array {
        $existing = $this->subjectModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Disciplina não encontrada.'];
        }

        $name = trim($data['name'] ?? '');
        if (empty($name)) {
            return ['success' => false, 'error' => 'O nome da disciplina é obrigatório.'];
        }

        try {
            $this->subjectModel->update($id, $userId, [
                'name' => $name,
                'code' => $data['code'] ?? null,
                'teacher' => $data['teacher'] ?? null,
                'classroom' => $data['classroom'] ?? null,
                'color' => $data['color'] ?? '#3B82F6'
            ]);

            $this->auditModel->log(
                $userId,
                'UPDATE',
                'materia',
                $id,
                "Atualizou a disciplina '{$name}'",
                ['name' => $existing['name']],
                ['name' => $name]
            );

            return ['success' => true];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao atualizar matéria {$id}: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao atualizar a disciplina.'];
        }
    }

    public function deleteSubject(int $id, int $userId): array {
        $existing = $this->subjectModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Disciplina não encontrada.'];
        }

        $this->subjectModel->delete($id, $userId);

        $this->auditModel->log(
            $userId,
            'DELETE',
            'materia',
            $id,
            "Excluiu a disciplina '{$existing['name']}'",
            ['name' => $existing['name']]
        );

        return ['success' => true];
    }
}
