<?php
/**
 * SOS-Estudante
 * Service de Horários e Grade de Aulas.
 */

require_once __DIR__ . '/../models/Schedule.php';
require_once __DIR__ . '/../models/Subject.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../config/app.php';

class ScheduleService {
    private Schedule $scheduleModel;
    private Subject $subjectModel;
    private AuditLog $auditModel;

    public function __construct() {
        $this->scheduleModel = new Schedule();
        $this->subjectModel = new Subject();
        $this->auditModel = new AuditLog();
    }

    public function listSchedule(int $userId): array {
        return $this->scheduleModel->getAllByUser($userId);
    }

    public function getTodayClasses(int $userId): array {
        // No PHP: 1 (Mon) a 7 (Sun)
        $dayOfWeek = (int)date('N');
        return $this->scheduleModel->getByUserAndDay($userId, $dayOfWeek);
    }

    public function createSchedule(int $userId, array $data): array {
        $subjectId = (int)($data['subject_id'] ?? 0);
        $dayOfWeek = (int)($data['day_of_week'] ?? 1);
        $startTime = trim($data['start_time'] ?? '');
        $endTime = trim($data['end_time'] ?? '');

        if ($subjectId <= 0) {
            return ['success' => false, 'error' => 'Selecione uma disciplina válida.'];
        }

        $subject = $this->subjectModel->getById($subjectId, $userId);
        if (!$subject) {
            return ['success' => false, 'error' => 'Disciplina não encontrada.'];
        }

        if ($dayOfWeek < 1 || $dayOfWeek > 7) {
            return ['success' => false, 'error' => 'Dia da semana inválido.'];
        }

        if (empty($startTime) || empty($endTime)) {
            return ['success' => false, 'error' => 'Horário inicial e final são obrigatórios.'];
        }

        if ($startTime >= $endTime) {
            return ['success' => false, 'error' => 'O horário inicial deve ser anterior ao horário final.'];
        }

        try {
            $id = $this->scheduleModel->create([
                'user_id' => $userId,
                'subject_id' => $subjectId,
                'day_of_week' => $dayOfWeek,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'room' => $data['room'] ?? $subject['classroom'],
                'notes' => $data['notes'] ?? null
            ]);

            $days = [1 => 'Segunda-feira', 2 => 'Terça-feira', 3 => 'Quarta-feira', 4 => 'Quinta-feira', 5 => 'Sexta-feira', 6 => 'Sábado', 7 => 'Domingo'];
            $dayName = $days[$dayOfWeek] ?? '';

            $this->auditModel->log(
                $userId,
                'CREATE',
                'horario',
                $id,
                "Adicionou aula de '{$subject['name']}' na {$dayName} ({$startTime} às {$endTime})"
            );

            return ['success' => true, 'id' => $id];
        } catch (Exception $e) {
            log_system('ERROR', "Erro ao adicionar horário: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro interno ao salvar horário de aula.'];
        }
    }

    public function deleteSchedule(int $id, int $userId): array {
        $existing = $this->scheduleModel->getById($id, $userId);
        if (!$existing) {
            return ['success' => false, 'error' => 'Horário não encontrado.'];
        }

        $this->scheduleModel->delete($id, $userId);

        $this->auditModel->log(
            $userId,
            'DELETE',
            'horario',
            $id,
            "Removeu aula da grade de horários."
        );

        return ['success' => true];
    }
}
